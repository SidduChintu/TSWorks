# ------------------------------------------------------------------------------
# Local variables & Constants
# ------------------------------------------------------------------------------

locals {
  final_resource_name = "${var.naming_convention_properties.project}-${var.naming_convention_properties.environment}"
  common_tags         = var.tags

  # Create Lambda integration URIs
  lambda_uris = {
    for k, v in var.lambda_integrations : k =>
    "arn:aws:apigateway:${data.aws_region.current.name}:lambda:path/2015-03-31/functions/${data.aws_lambda_function.this[k].arn}/invocations"
  }

  # Map resource keys to their IDs
  resource_ids = merge(
    { "root" = aws_api_gateway_rest_api.this.root_resource_id },
    { for k, v in aws_api_gateway_resource.this : k => v.id }
  )
}

data "aws_region" "current" {}

# ------------------------------------------------------------------------------
# AWS API Gateway REST API
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_rest_api
# This resource creates the API Gateway REST API with configurable properties
# including name, description, endpoint configuration, and OpenAPI specification.
# ------------------------------------------------------------------------------

resource "aws_api_gateway_rest_api" "this" {
  name        = "${var.naming_convention_properties.project}-api-gateway-${var.naming_convention_properties.environment}-${var.api_name}"
  description = var.api_description
  body        = var.openapi_spec
  endpoint_configuration {
    types = [var.endpoint_type]
  }
  binary_media_types = ["*/*"]
  tags               = local.common_tags
}

# ------------------------------------------------------------------------------
# AWS API Gateway Resources
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_resource
# This resource creates API Gateway resources with configurable path parts and parent IDs.
# ------------------------------------------------------------------------------

resource "aws_api_gateway_resource" "this" {
  for_each    = var.resources
  rest_api_id = aws_api_gateway_rest_api.this.id
  parent_id   = each.value.parent_id == "root" ? aws_api_gateway_rest_api.this.root_resource_id : each.value.parent_id
  path_part   = each.value.path_part
}

# ------------------------------------------------------------------------------
# AWS Lambda Function Data Source
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/lambda_function
# This data source fetches information about Lambda functions for integration.
# ------------------------------------------------------------------------------

data "aws_lambda_function" "this" {
  for_each      = var.lambda_integrations
  function_name = each.value.lambda_function_name
}

# ------------------------------------------------------------------------------
# AWS API Gateway Methods
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_method
# This resource creates API Gateway methods with configurable HTTP methods,
# authorization, request models, and parameters.
# ------------------------------------------------------------------------------

resource "aws_api_gateway_method" "this" {
  for_each         = var.methods
  rest_api_id      = aws_api_gateway_rest_api.this.id
  resource_id      = local.resource_ids[each.value.resource_key]
  http_method      = each.value.http_method
  authorization    = each.value.authorization
  authorizer_id    = each.value.authorizer_id
  api_key_required = each.value.api_key_required

  request_models     = each.value.request_models
  request_parameters = each.value.request_parameters

  lifecycle {
    ignore_changes = [api_key_required]
  }

  depends_on = [aws_api_gateway_resource.this]
}

# ------------------------------------------------------------------------------
# AWS API Gateway Integrations
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration
# This resource creates API Gateway integrations with various backend services.
# ------------------------------------------------------------------------------

resource "aws_api_gateway_integration" "this" {
  for_each                = var.integrations
  rest_api_id             = aws_api_gateway_rest_api.this.id
  resource_id             = local.resource_ids[each.value.resource_key]
  http_method             = each.value.http_method
  integration_http_method = each.value.integration_http_method
  type                    = each.value.type
  uri                     = each.value.uri
  connection_type         = each.value.connection_type
  connection_id           = each.value.connection_id
  credentials             = each.value.credentials

  request_parameters = each.value.request_parameters
  request_templates  = each.value.request_templates

  depends_on = [aws_api_gateway_method.this]
}

# ------------------------------------------------------------------------------
# AWS API Gateway Lambda Integrations
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_integration
# This resource creates API Gateway integrations specifically for Lambda functions.
# ------------------------------------------------------------------------------

resource "aws_api_gateway_integration" "lambda" {
  for_each                = var.lambda_integrations
  rest_api_id             = aws_api_gateway_rest_api.this.id
  resource_id             = local.resource_ids[each.value.resource_key]
  http_method             = each.value.http_method
  integration_http_method = each.value.integration_http_method
  type                    = each.value.type
  uri                     = local.lambda_uris[each.key]
  connection_type         = each.value.connection_type
  connection_id           = each.value.connection_id
  credentials             = each.value.credentials

  request_parameters = each.value.request_parameters
  request_templates  = each.value.request_templates

  depends_on = [aws_api_gateway_method.this]
}

# ------------------------------------------------------------------------------
# AWS API Gateway Deployment
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_deployment
# This resource deploys the API Gateway configuration to a stage.
# ------------------------------------------------------------------------------

resource "aws_api_gateway_deployment" "this" {
  rest_api_id = aws_api_gateway_rest_api.this.id
  description = var.deployment_description

  triggers = {
    redeployment = sha1(jsonencode([
      aws_api_gateway_rest_api.this.body,
      var.resources,
      var.methods,
      var.integrations
    ]))
  }

  lifecycle {
    create_before_destroy = true
  }

  depends_on = [
    aws_api_gateway_method.this,
    aws_api_gateway_integration.this,
    aws_api_gateway_integration.lambda
  ]
}

# ------------------------------------------------------------------------------
# AWS API Gateway CloudWatch Logging Role
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role
# This resource creates an IAM role for API Gateway to write logs to CloudWatch.
# ------------------------------------------------------------------------------

resource "aws_iam_role" "api_gateway_cloudwatch" {
  count = var.enable_logging ? 1 : 0

  name = "${var.naming_convention_properties.project}-api-gateway-${var.naming_convention_properties.environment}-${var.api_name}-api-gateway-cloudwatch"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "apigateway.amazonaws.com"
        }
      }
    ]
  })
}

# ------------------------------------------------------------------------------
# AWS API Gateway CloudWatch Logging Policy Attachment
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment
# This resource attaches the necessary policy to the CloudWatch logging role.
# ------------------------------------------------------------------------------

resource "aws_iam_role_policy_attachment" "api_gateway_cloudwatch" {
  count = var.enable_logging ? 1 : 0

  role       = aws_iam_role.api_gateway_cloudwatch[0].name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonAPIGatewayPushToCloudWatchLogs"
}

# ------------------------------------------------------------------------------
# AWS API Gateway Account Settings
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_account
# This resource configures API Gateway account-level settings including CloudWatch role.
# ------------------------------------------------------------------------------

resource "aws_api_gateway_account" "this" {
  count = var.enable_logging ? 1 : 0

  cloudwatch_role_arn = aws_iam_role.api_gateway_cloudwatch[0].arn
}

# ------------------------------------------------------------------------------
# AWS API Gateway Stage
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_stage
# This resource creates an API Gateway stage with configurable settings.
# ------------------------------------------------------------------------------

resource "aws_api_gateway_stage" "this" {
  deployment_id = aws_api_gateway_deployment.this.id
  rest_api_id   = aws_api_gateway_rest_api.this.id
  stage_name    = var.stage_name

  dynamic "access_log_settings" {
    for_each = var.access_log_settings != null ? [var.access_log_settings] : []
    content {
      destination_arn = access_log_settings.value.destination_arn
      format          = access_log_settings.value.format
    }
  }

  variables = var.stage_variables
}

# ------------------------------------------------------------------------------
# AWS API Gateway Method Settings
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_method_settings
# This resource configures method-level settings for API Gateway.
# ------------------------------------------------------------------------------

resource "aws_api_gateway_method_settings" "this" {
  for_each    = var.method_settings
  rest_api_id = aws_api_gateway_rest_api.this.id
  stage_name  = aws_api_gateway_stage.this.stage_name
  method_path = each.key

  settings {
    metrics_enabled        = lookup(each.value, "metrics_enabled", false)
    logging_level          = lookup(each.value, "logging_level", "OFF")
    data_trace_enabled     = lookup(each.value, "data_trace_enabled", false)
    throttling_burst_limit = lookup(each.value, "throttling_burst_limit", null)
    throttling_rate_limit  = lookup(each.value, "throttling_rate_limit", null)
  }

  depends_on = [aws_api_gateway_account.this]
}

# ------------------------------------------------------------------------------
# AWS API Gateway API Keys
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_api_key
# This resource creates API keys for API Gateway.
# ------------------------------------------------------------------------------

resource "aws_api_gateway_api_key" "this" {
  for_each = var.api_keys
  name     = each.key
  value    = each.value.value
  enabled  = each.value.enabled
}

# ------------------------------------------------------------------------------
# AWS API Gateway Usage Plan
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_usage_plan
# This resource creates usage plans for API Gateway.
# ------------------------------------------------------------------------------

resource "aws_api_gateway_usage_plan" "this" {
  count       = var.create_usage_plan ? 1 : 0
  name        = var.usage_plan_name
  description = var.usage_plan_description

  dynamic "api_stages" {
    for_each = var.usage_plan_api_stages
    content {
      api_id = api_stages.value.api_id
      stage  = api_stages.value.stage
    }
  }

  dynamic "quota_settings" {
    for_each = var.usage_plan_quota_settings != null ? [var.usage_plan_quota_settings] : []
    content {
      limit  = quota_settings.value.limit
      offset = quota_settings.value.offset
      period = quota_settings.value.period
    }
  }

  dynamic "throttle_settings" {
    for_each = var.usage_plan_throttle_settings != null ? [var.usage_plan_throttle_settings] : []
    content {
      burst_limit = throttle_settings.value.burst_limit
      rate_limit  = throttle_settings.value.rate_limit
    }
  }
}

# ------------------------------------------------------------------------------
# AWS API Gateway Usage Plan Key
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/api_gateway_usage_plan_key
# This resource associates API keys with usage plans.
# ------------------------------------------------------------------------------

resource "aws_api_gateway_usage_plan_key" "this" {
  for_each      = var.usage_plan_keys
  key_id        = each.value.key_id
  key_type      = each.value.key_type
  usage_plan_id = each.value.usage_plan_id
}

# ------------------------------------------------------------------------------
# AWS Lambda Permissions for API Gateway
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission
# This resource grants API Gateway permission to invoke Lambda functions.
# ------------------------------------------------------------------------------

resource "aws_lambda_permission" "api_gateway" {
  for_each      = var.lambda_integrations
  statement_id  = "AllowExecutionFromAPIGateway-${each.key}"
  action        = "lambda:InvokeFunction"
  function_name = each.value.lambda_function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_api_gateway_rest_api.this.execution_arn}/*/${each.value.http_method}/*"

  depends_on = [aws_api_gateway_integration.lambda]
}