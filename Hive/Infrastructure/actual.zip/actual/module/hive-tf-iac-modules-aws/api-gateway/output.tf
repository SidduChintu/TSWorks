# ------------------------------------------------------------------------------
# API Gateway Outputs
#
# USAGE EXAMPLES:
# All outputs can be referenced in other modules using: module.api_gateway.<output_name>
# ------------------------------------------------------------------------------

output "rest_api_id" {
  description = "The ID of the REST API gateway resource"
  value       = aws_api_gateway_rest_api.this.id
  # Example usage:
  # - module.api_gateway.rest_api_id
  # - Use when creating API Gateway resources or integrations
}

output "root_resource_id" {
  description = "The resource ID of the API Gateway root resource ('/')"
  value       = aws_api_gateway_rest_api.this.root_resource_id
  # Example usage:
  # - module.api_gateway.root_resource_id
  # - Use when adding methods to the root path
}

output "execution_arn" {
  description = "The execution ARN for API Gateway to invoke integrations (format: arn:aws:execute-api:<region>:<account-id>:<api-id>/*)"
  value       = aws_api_gateway_rest_api.this.execution_arn
  # Example usage:
  # - module.api_gateway.execution_arn
  # - Use in IAM policies for API Gateway execution permissions
}

output "arn" {
  description = "The full ARN of the REST API resource"
  value       = aws_api_gateway_rest_api.this.arn
  # Example usage:
  # - module.api_gateway.arn
  # - Use for IAM policies requiring API Gateway ARN
}

output "created_date" {
  description = "The timestamp when the REST API was created (RFC 3339 format)"
  value       = aws_api_gateway_rest_api.this.created_date
  # Example usage:
  # - module.api_gateway.created_date
  # - Use for auditing or monitoring purposes
}

output "deployment_id" {
  description = "The unique identifier of the API Gateway deployment"
  value       = aws_api_gateway_deployment.this.id
  # Example usage:
  # - module.api_gateway.deployment_id
  # - Use when managing deployment lifecycle
}

output "stage_name" {
  description = "The name of the deployed API Gateway stage (e.g., 'prod', 'dev', 'v1')"
  value       = aws_api_gateway_stage.this.stage_name
  # Example usage:
  # - module.api_gateway.stage_name
  # - Use when constructing invocation URLs or for stage-specific configurations
}

output "stage_arn" {
  description = "The ARN of the API Gateway stage"
  value       = aws_api_gateway_stage.this.arn
  # Example usage:
  # - module.api_gateway.stage_arn
  # - Use for stage-specific IAM policies
}

output "invoke_url" {
  description = "The base URL for API invocation (format: https://<api-id>.execute-api.<region>.amazonaws.com/<stage-name>)"
  value       = "${aws_api_gateway_deployment.this.invoke_url}/${aws_api_gateway_stage.this.stage_name}"
  # Example usage:
  # - module.api_gateway.invoke_url
  # - Use as the base URL for API clients and applications
}

output "resource_ids" {
  description = "Map of API resource path parts to their corresponding resource IDs"
  value       = { for k, v in aws_api_gateway_resource.this : k => v.id }
  # Example usage:
  # - module.api_gateway.resource_ids["my_resource_path"]
  # - Use when adding methods or integrations to specific resources
}

output "api_key_values" {
  description = "Map of API key names to their generated values (marked as sensitive)"
  value       = { for k, v in aws_api_gateway_api_key.this : k => v.value }
  sensitive   = true
  # Example usage:
  # - module.api_gateway.api_key_values["my_key_name"] (will be redacted in output)
  # - Use for initial client configuration (store securely)
}

output "usage_plan_id" {
  description = "The ID of the API Gateway usage plan if created"
  value       = try(aws_api_gateway_usage_plan.this[0].id, "")
  # Example usage:
  # - module.api_gateway.usage_plan_id
  # - Use when associating API keys or throttling settings
}