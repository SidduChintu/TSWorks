# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

# ------------------------------------------------------------------------------
# API Gateway Variables
# This section defines the variables required for creating an AWS API Gateway.
# It includes configurations for the API Gateway, resources, methods, integrations,
# deployments, stages, logging, usage plans, and Lambda integrations.
# The `api_gateway` variable is a map where each key corresponds to an API Gateway name
# and the value is an object containing the API Gateway's properties.
# ------------------------------------------------------------------------------

variable "api_name" {
  description = "Name of the API Gateway"
  type        = string
}

variable "api_description" {
  description = "Description of the API Gateway"
  type        = string
  default     = null
}

variable "endpoint_type" {
  description = "Endpoint type for the API Gateway"
  type        = string
  default     = "REGIONAL"
}

variable "openapi_spec" {
  description = "OpenAPI specification body"
  type        = string
  default     = null
}

variable "resources" {
  description = "Map of API Gateway resources"
  type = map(object({
    parent_id = string
    path_part = string
  }))
  default = {}
}

variable "methods" {
  description = "Map of API Gateway methods"
  type = map(object({
    resource_key       = string
    http_method        = string
    authorization      = string
    authorizer_id      = optional(string)
    api_key_required   = optional(bool, false)
    request_models     = optional(map(string))
    request_parameters = optional(map(bool))
  }))
  default = {}
}

variable "integrations" {
  description = "Map of API Gateway integrations"
  type = map(object({
    resource_key            = string
    http_method             = string
    integration_http_method = optional(string)
    type                    = string
    uri                     = optional(string)
    connection_type         = optional(string)
    connection_id           = optional(string)
    credentials             = optional(string)
    request_parameters      = optional(map(string))
    request_templates       = optional(map(string))
  }))
  default = {}
}

variable "deployment_description" {
  description = "Description of the deployment"
  type        = string
  default     = "Deployed by Terraform"
}

variable "enable_logging" {
  description = "Whether to enable CloudWatch logging for API Gateway"
  type        = bool
  default     = false
}

variable "stage_name" {
  description = "Name of the deployment stage"
  type        = string
}

variable "stage_variables" {
  description = "Map of stage variables"
  type        = map(string)
  default     = {}
}

variable "access_log_settings" {
  description = "Access log settings for the stage"
  type = object({
    destination_arn = string
    format          = string
  })
  default = null
}

variable "method_settings" {
  description = "Map of method settings to apply"
  type = map(object({
    metrics_enabled        = optional(bool)
    logging_level          = optional(string)
    data_trace_enabled     = optional(bool)
    throttling_burst_limit = optional(number)
    throttling_rate_limit  = optional(number)
  }))
  default = {}
}

variable "api_keys" {
  description = "Map of API keys"
  type = map(object({
    value   = optional(string)
    enabled = optional(bool, true)
  }))
  default = {}
}

variable "create_usage_plan" {
  description = "Whether to create a usage plan"
  type        = bool
  default     = false
}

variable "usage_plan_name" {
  description = "Name of the usage plan"
  type        = string
  default     = null
}

variable "usage_plan_description" {
  description = "Description of the usage plan"
  type        = string
  default     = null
}

variable "usage_plan_api_stages" {
  description = "List of API stages for the usage plan"
  type = list(object({
    api_id = string
    stage  = string
  }))
  default = []
}

variable "usage_plan_quota_settings" {
  description = "Quota settings for the usage plan"
  type = object({
    limit  = number
    offset = optional(number, 0)
    period = string
  })
  default = null
}

variable "usage_plan_throttle_settings" {
  description = "Throttle settings for the usage plan"
  type = object({
    burst_limit = number
    rate_limit  = number
  })
  default = null
}

variable "lambda_integrations" {
  description = "Map of Lambda integrations with automatic URI generation"
  type = map(object({
    lambda_function_name    = string
    resource_key            = string
    http_method             = string
    integration_http_method = optional(string, "POST")
    type                    = optional(string, "AWS_PROXY")
    connection_type         = optional(string)
    connection_id           = optional(string)
    credentials             = optional(string)
    request_parameters      = optional(map(string))
    request_templates       = optional(map(string))
  }))
  default = {}
}

variable "usage_plan_keys" {
  description = "Map of usage plan keys"
  type = map(object({
    key_id        = string
    key_type      = string
    usage_plan_id = string
  }))
  default = {}
}

variable "tags" {
  description = "Tags to apply to resources"
  type        = map(string)
  default     = {}
}