# ----------------------------------------------------------------------------
# EC2 Instance Module
# This module creates EC2 instances with associated security groups and IAM instance profiles.
# It supports multiple instances with customizable configurations.
# ------------------------------------------------------------------------------

resource "aws_security_group" "this" {
  for_each = var.instances

  name        = "${var.naming_convention_properties.project}-ec2-sg-${var.naming_convention_properties.environment}-${each.value.sg_name}"
  description = each.value.sg_description
  vpc_id      = each.value.vpc_id

  dynamic "ingress" {
    for_each = try(each.value.sg_ingress, [])
    content {
      from_port   = ingress.value.from_port
      to_port     = ingress.value.to_port
      protocol    = ingress.value.protocol
      cidr_blocks = ingress.value.cidr_blocks
    }
  }

  dynamic "egress" {
    for_each = try(each.value.sg_egress, [])
    content {
      from_port   = egress.value.from_port
      to_port     = egress.value.to_port
      protocol    = egress.value.protocol
      cidr_blocks = egress.value.cidr_blocks
    }
  }

  tags = merge(each.value.tags, { Name = each.value.sg_name })
}

resource "aws_iam_instance_profile" "this" {
  for_each = { for k, v in var.instances : k => v if v.iam_instance_profile != null }

  name = each.value.iam_instance_profile
  role = each.value.iam_instance_profile
}

resource "aws_instance" "this" {
  for_each = var.instances

  ami                         = each.value.ami
  instance_type               = each.value.instance_type
  key_name                    = each.value.key_name
  subnet_id                   = each.value.subnet_id
  vpc_security_group_ids      = [aws_security_group.this[each.key].id]
  iam_instance_profile        = try(each.value.iam_instance_profile, null)
  user_data                   = try(each.value.user_data, null)
  user_data_base64            = try(each.value.user_data_base64, null)
  availability_zone           = try(each.value.availability_zone, null)
  associate_public_ip_address = try(each.value.associate_public_ip_address, false)
  monitoring                  = try(each.value.monitoring, null)
  ebs_optimized               = try(each.value.ebs_optimized, null)
  disable_api_termination     = try(each.value.disable_api_termination, null)
  disable_api_stop            = try(each.value.disable_api_stop, null)
  tenancy                     = try(each.value.tenancy, null)
  host_id                     = try(each.value.host_id, null)
  placement_group             = try(each.value.placement_group, null)
  hibernation                 = try(each.value.hibernation, null)

  dynamic "capacity_reservation_specification" {
    for_each = try(each.value.capacity_reservation_specification, null) != null ? [each.value.capacity_reservation_specification] : []
    content {
      capacity_reservation_preference = lookup(capacity_reservation_specification.value, "capacity_reservation_preference", null)
      dynamic "capacity_reservation_target" {
        for_each = lookup(capacity_reservation_specification.value, "capacity_reservation_target", null) != null ? [lookup(capacity_reservation_specification.value, "capacity_reservation_target")] : []
        content {
          capacity_reservation_id                 = lookup(capacity_reservation_target.value, "capacity_reservation_id", null)
          capacity_reservation_resource_group_arn = lookup(capacity_reservation_target.value, "capacity_reservation_resource_group_arn", null)
        }
      }
    }
  }

  dynamic "cpu_options" {
    for_each = try(each.value.cpu_options, null) != null ? [each.value.cpu_options] : []
    content {
      amd_sev_snp      = lookup(cpu_options.value, "amd_sev_snp", null)
      core_count       = lookup(cpu_options.value, "core_count", null)
      threads_per_core = lookup(cpu_options.value, "threads_per_core", null)
    }
  }

  dynamic "credit_specification" {
    for_each = try(each.value.credit_specification, null) != null ? [each.value.credit_specification] : []
    content {
      cpu_credits = credit_specification.value.cpu_credits
    }
  }

  dynamic "enclave_options" {
    for_each = try(each.value.enclave_options, null) != null ? [each.value.enclave_options] : []
    content {
      enabled = enclave_options.value.enabled
    }
  }

  dynamic "instance_market_options" {
    for_each = try(each.value.instance_market_options, null) != null ? [each.value.instance_market_options] : []
    content {
      market_type = instance_market_options.value.market_type
      dynamic "spot_options" {
        for_each = lookup(instance_market_options.value, "spot_options", null) != null ? [lookup(instance_market_options.value, "spot_options")] : []
        content {
          instance_interruption_behavior = lookup(spot_options.value, "instance_interruption_behavior", null)
          max_price                      = lookup(spot_options.value, "max_price", null)
          spot_instance_type             = lookup(spot_options.value, "spot_instance_type", null)
          valid_until                    = lookup(spot_options.value, "valid_until", null)
        }
      }
    }
  }

  dynamic "metadata_options" {
    for_each = try(each.value.metadata_options, null) != null ? [each.value.metadata_options] : []
    content {
      http_endpoint               = lookup(metadata_options.value, "http_endpoint", "enabled")
      http_protocol_ipv6          = lookup(metadata_options.value, "http_protocol_ipv6", "disabled")
      http_put_response_hop_limit = lookup(metadata_options.value, "http_put_response_hop_limit", 1)
      http_tokens                 = lookup(metadata_options.value, "http_tokens", "optional")
      instance_metadata_tags      = lookup(metadata_options.value, "instance_metadata_tags", "disabled")
    }
  }

  dynamic "root_block_device" {
    for_each = try(each.value.root_block_device, null) != null ? [each.value.root_block_device] : []
    content {
      delete_on_termination = lookup(root_block_device.value, "delete_on_termination", true)
      encrypted             = lookup(root_block_device.value, "encrypted", false)
      iops                  = lookup(root_block_device.value, "iops", null)
      kms_key_id            = lookup(root_block_device.value, "kms_key_id", null)
      throughput            = lookup(root_block_device.value, "throughput", null)
      volume_size           = lookup(root_block_device.value, "volume_size", null)
      volume_type           = lookup(root_block_device.value, "volume_type", "gp2")
      tags                  = lookup(root_block_device.value, "tags", null)
    }
  }

  dynamic "ebs_block_device" {
    for_each = try(each.value.ebs_block_devices, null) != null ? each.value.ebs_block_devices : []
    content {
      delete_on_termination = lookup(ebs_block_device.value, "delete_on_termination", true)
      device_name           = ebs_block_device.value.device_name
      encrypted             = lookup(ebs_block_device.value, "encrypted", false)
      iops                  = lookup(ebs_block_device.value, "iops", null)
      kms_key_id            = lookup(ebs_block_device.value, "kms_key_id", null)
      snapshot_id           = lookup(ebs_block_device.value, "snapshot_id", null)
      throughput            = lookup(ebs_block_device.value, "throughput", null)
      volume_size           = lookup(ebs_block_device.value, "volume_size", null)
      volume_type           = lookup(ebs_block_device.value, "volume_type", "gp2")
      tags                  = lookup(ebs_block_device.value, "tags", null)
    }
  }

  dynamic "ephemeral_block_device" {
    for_each = try(each.value.ephemeral_block_devices, null) != null ? each.value.ephemeral_block_devices : []
    content {
      device_name  = ephemeral_block_device.value.device_name
      no_device    = lookup(ephemeral_block_device.value, "no_device", null)
      virtual_name = lookup(ephemeral_block_device.value, "virtual_name", null)
    }
  }

  dynamic "network_interface" {
    for_each = try(each.value.network_interfaces, null) != null ? each.value.network_interfaces : []
    content {
      device_index          = network_interface.value.device_index
      network_interface_id  = network_interface.value.network_interface_id
      delete_on_termination = lookup(network_interface.value, "delete_on_termination", false)
      network_card_index    = lookup(network_interface.value, "network_card_index", 0)
    }
  }

  tags        = merge(var.tags, each.value.tags, { "Name" = format("%s-ec2-%s-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment, each.value.name) })
  volume_tags = try(each.value.volume_tags, null)
}