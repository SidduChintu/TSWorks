# ------------------------------------------------------------------------------
# EC2 Instance Module Outputs
#
# USAGE EXAMPLES:
# All outputs can be referenced in other modules using: module.ec2.<output_name>
# ------------------------------------------------------------------------------

output "instance_ids" {
  description = "Map of EC2 instance IDs keyed by instance name"
  value       = { for k, inst in aws_instance.this : k => inst.id }
  # Example usage:
  # - module.ec2.instance_ids["web_server"]
  # - Use for referencing instances in other resources, CLI commands, or automation scripts
}

output "public_ips" {
  description = "Map of public IP addresses assigned to EC2 instances"
  value       = { for k, inst in aws_instance.this : k => inst.public_ip }
  # Example usage:
  # - module.ec2.public_ips["web_server"]
  # - Use for SSH access, load balancer configuration, or external service integration
}

output "private_ips" {
  description = "Map of private IP addresses assigned to EC2 instances"
  value       = { for k, inst in aws_instance.this : k => inst.private_ip }
  # Example usage:
  # - module.ec2.private_ips["database_server"]
  # - Use for internal networking, VPC peering, or private service communication
}

output "security_group_ids" {
  description = "Map of security group IDs created for each EC2 instance"
  value       = { for k, sg in aws_security_group.this : k => sg.id }
  # Example usage:
  # - module.ec2.security_group_ids["web_server_sg"]
  # - Use for updating security group rules, IAM policies, or cross-resource references
}