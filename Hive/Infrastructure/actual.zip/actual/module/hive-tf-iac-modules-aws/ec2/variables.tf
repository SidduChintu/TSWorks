# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}

# ------------------------------------------------------------------------------
# EC2 Instance Configuration
# This module defines the configuration for AWS EC2 instances.
# ------------------------------------------------------------------------------

variable "instances" {
  description = "Map of EC2 instance configurations"
  type = map(object({
    name           = string
    ami            = string
    instance_type  = string
    key_name       = string
    subnet_id      = string
    vpc_id         = optional(string)
    sg_name        = string
    sg_description = string
    sg_ingress = list(object({
      from_port   = number
      to_port     = number
      protocol    = string
      cidr_blocks = list(string)
    }))
    sg_egress = list(object({
      from_port   = number
      to_port     = number
      protocol    = string
      cidr_blocks = list(string)
    }))
    iam_instance_profile        = optional(string)
    user_data                   = optional(string)
    user_data_base64            = optional(string)
    availability_zone           = optional(string)
    associate_public_ip_address = optional(bool)
    monitoring                  = optional(bool)
    ebs_optimized               = optional(bool)
    disable_api_termination     = optional(bool)
    disable_api_stop            = optional(bool)
    tenancy                     = optional(string)
    host_id                     = optional(string)
    placement_group             = optional(string)
    hibernation                 = optional(bool)
    capacity_reservation_specification = optional(object({
      capacity_reservation_preference = optional(string)
      capacity_reservation_target = optional(object({
        capacity_reservation_id                 = optional(string)
        capacity_reservation_resource_group_arn = optional(string)
      }))
    }))
    cpu_options = optional(object({
      amd_sev_snp      = optional(string)
      core_count       = optional(number)
      threads_per_core = optional(number)
    }))
    credit_specification = optional(object({
      cpu_credits = string
    }))
    enclave_options = optional(object({
      enabled = bool
    }))
    instance_market_options = optional(object({
      market_type = string
      spot_options = optional(object({
        instance_interruption_behavior = optional(string)
        max_price                      = optional(string)
        spot_instance_type             = optional(string)
        valid_until                    = optional(string)
      }))
    }))
    metadata_options = optional(object({
      http_endpoint               = optional(string)
      http_protocol_ipv6          = optional(string)
      http_put_response_hop_limit = optional(number)
      http_tokens                 = optional(string)
      instance_metadata_tags      = optional(string)
    }))
    root_block_device = optional(object({
      delete_on_termination = optional(bool)
      encrypted             = optional(bool)
      iops                  = optional(number)
      kms_key_id            = optional(string)
      throughput            = optional(number)
      volume_size           = optional(number)
      volume_type           = optional(string)
      tags                  = optional(map(string))
    }))
    ebs_block_devices = optional(list(object({
      delete_on_termination = optional(bool)
      device_name           = string
      encrypted             = optional(bool)
      iops                  = optional(number)
      kms_key_id            = optional(string)
      snapshot_id           = optional(string)
      throughput            = optional(number)
      volume_size           = optional(number)
      volume_type           = optional(string)
      tags                  = optional(map(string))
    })))
    ephemeral_block_devices = optional(list(object({
      device_name  = string
      no_device    = optional(string)
      virtual_name = optional(string)
    })))
    network_interfaces = optional(list(object({
      device_index          = number
      network_interface_id  = string
      delete_on_termination = optional(bool)
      network_card_index    = optional(number)
    })))
    tags        = map(string)
    volume_tags = optional(map(string))
  }))
}

