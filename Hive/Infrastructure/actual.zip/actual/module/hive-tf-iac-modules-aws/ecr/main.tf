# ----------------------------------------------------------------------------
# ECR Repository Module
# This module creates an AWS ECR repository with customizable configurations.
# It supports encryption, image scanning, and tagging.
# ------------------------------------------------------------------------------

resource "aws_ecr_repository" "this" {
  name                 = "${var.naming_convention_properties.project}-ecr-${var.naming_convention_properties.environment}-${var.repository_name}"
  image_tag_mutability = var.image_tag_mutability
  force_delete         = var.force_delete

  # Encryption configuration
  dynamic "encryption_configuration" {
    for_each = var.encryption_configuration != null ? [var.encryption_configuration] : []

    content {
      encryption_type = encryption_configuration.value.encryption_type
      kms_key         = encryption_configuration.value.kms_key
    }
  }

  # Image scanning configuration
  dynamic "image_scanning_configuration" {
    for_each = var.image_scanning_configuration != null ? [var.image_scanning_configuration] : []

    content {
      scan_on_push = image_scanning_configuration.value.scan_on_push
    }
  }

  tags = var.tags
}

resource "aws_ecr_lifecycle_policy" "this" {
  # Only create this resource if a lifecycle_policy was provided
  count = try(length(var.lifecycle_policy.rules), 0) > 0 ? 1 : 0

  repository = aws_ecr_repository.this.name
  # The policy must be a JSON string. Using jsonencode on the input variable.
  policy = jsonencode(try(var.lifecycle_policy, null))
}