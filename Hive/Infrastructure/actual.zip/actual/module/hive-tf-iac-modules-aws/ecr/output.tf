# ------------------------------------------------------------------------------
# ECR Repository Outputs
#
# USAGE EXAMPLES:
# All outputs can be referenced in other modules using: module.ecr.<output_name>
# ------------------------------------------------------------------------------

output "repository_arn" {
  description = "Full ARN of the repository"
  value       = aws_ecr_repository.this.arn
  # Example usage:
  # - module.ecr.repository_arn
  # - Use for IAM policies, resource references, or cross-service integrations
}

output "repository_url" {
  description = "The URL of the repository (can be used with docker push/pull commands)"
  value       = aws_ecr_repository.this.repository_url
  # Example usage:
  # - module.ecr.repository_url
  # - Use for Docker CLI commands, CI/CD pipelines, or container deployment scripts
}

output "registry_id" {
  description = "The registry ID where the repository was created (typically AWS account ID)"
  value       = aws_ecr_repository.this.registry_id
  # Example usage:
  # - module.ecr.registry_id
  # - Use for ECR API calls, cross-account access, or registry-specific operations
}