# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

variable "tags" {
  description = "Tags to assign to the repository"
  type        = map(string)
  default     = {}
}

# ------------------------------------------------------------------------------
# ECR Repository Configuration
# This module defines the configuration for AWS ECR repositories.
# ------------------------------------------------------------------------------

variable "repository_name" {
  description = "Name of the ECR repository"
  type        = string
}

variable "image_tag_mutability" {
  description = "The tag mutability setting for the repository"
  type        = string
  default     = "MUTABLE"
}

variable "force_delete" {
  description = "If true, will delete the repository even if it contains images"
  type        = bool
  default     = false
}

variable "encryption_configuration" {
  description = "Encryption configuration for the repository"
  type = object({
    encryption_type = optional(string, "AES256")
    kms_key         = optional(string, null)
  })
  default = {}
}

variable "image_scanning_configuration" {
  description = "Image scanning configuration for the repository"
  type = object({
    scan_on_push = optional(bool, false)
  })
  default = {}
}

variable "lifecycle_policy" {
  description = "A map representing the lifecycle policy for the ECR repository."
  type        = any
  default     = null
}