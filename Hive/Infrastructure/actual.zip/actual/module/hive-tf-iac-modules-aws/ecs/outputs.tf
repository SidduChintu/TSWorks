# ------------------------------------------------------------------------------
# ECS Module Outputs
# Only include outputs for resources that THIS module actually creates
# ------------------------------------------------------------------------------

# Cluster outputs (only if cluster is created)
output "cluster_arn" {
  description = "ARN of the ECS cluster"
  value       = var.create_cluster ? aws_ecs_cluster.this[0].arn : null
}

output "cluster_name" {
  description = "Name of the ECS cluster"
  value       = var.create_cluster ? aws_ecs_cluster.this[0].name : null
}

output "cluster_id" {
  description = "ID of the ECS cluster"
  value       = var.create_cluster ? aws_ecs_cluster.this[0].id : null
}

# Task Definition outputs (only if task definition is created)
output "task_definition_arn" {
  description = "ARN of the ECS task definition"
  value       = var.create_task_definition ? aws_ecs_task_definition.this[0].arn : null
}

output "task_definition_family" {
  description = "Family of the ECS task definition"
  value       = var.create_task_definition ? aws_ecs_task_definition.this[0].family : null
}

# Log Group outputs (only if task definition is created)
output "log_group_name" {
  description = "Name of the CloudWatch log group"
  value       = var.create_task_definition ? aws_cloudwatch_log_group.ecs_task[0].name : null
}

output "log_group_arn" {
  description = "ARN of the CloudWatch log group"
  value       = var.create_task_definition ? aws_cloudwatch_log_group.ecs_task[0].arn : null
}


# # ------------------------------------------------------------------------------
# # ECS Module Outputs
# # ------------------------------------------------------------------------------

# output "ecr_repository_urls" {
#   description = "URLs of the ECR repositories"
#   value = {
#     for k, v in module.ecr_repositories : k => v.repository_url
#   }
# }

# output "ecr_repository_arns" {
#   description = "ARNs of the ECR repositories"
#   value = {
#     for k, v in module.ecr_repositories : k => v.repository_arn
#   }
# }

# # IAM Role Outputs
# output "iam_role_arns" {
#   description = "ARNs of the IAM roles"
#   value       = module.iam_roles.role_arns
# }

# output "task_role_arn" {
#   description = "ARN of the ECS Task Role"
#   value       = module.iam_roles.iam_roles["ecsTaskRole"].arn
# }

# output "execution_role_arn" {
#   description = "ARN of the ECS Execution Role"
#   value       = module.iam_roles.iam_roles["ecsExecutionRole"].arn
# }

# # ECS Cluster Outputs
# output "ecs_cluster_ids" {
#   description = "IDs of the ECS clusters"
#   value = {
#     for k, v in module.ecs_clusters : k => v.cluster_id
#   }
# }

# output "ecs_cluster_arns" {
#   description = "ARNs of the ECS clusters"
#   value = {
#     for k, v in module.ecs_clusters : k => v.cluster_arn
#   }
# }

# output "ecs_cluster_names" {
#   description = "Names of the ECS clusters"
#   value = {
#     for k, v in module.ecs_clusters : k => v.cluster_name
#   }
# }

# output "task_definition_arns" {
#   description = "ARNs of the ECS task definitions"
#   value = {
#     for k, v in module.ecs_task_definitions : k => v.task_definition_arn
#   }
# }

# output "task_definition_families" {
#   description = "Families of the ECS task definitions"
#   value = {
#     for k, v in module.ecs_task_definitions : k => v.task_definition_family
#   }
# }

# output "log_group_names" {
#   description = "Names of the CloudWatch Log Groups"
#   value = {
#     for k, v in module.ecs_task_definitions : k => v.log_group_name
#   }
# }

# # Task to Cluster Mapping
# # output "task_cluster_mapping" {
# #   description = "Mapping of task definitions to their clusters"
# #   value = {
# #     for k, v in var.ecs_task_definitions : k => {
# #       task_arn    = module.ecs_task_definitions[k].task_definition_arn
# #       cluster_key = v.cluster_key
# #       cluster_arn = module.ecs_clusters[v.cluster_key].cluster_arn
# #     }
# #   }
# # }

# output "task_definition_revision" {
#   description = "The revision of the task in a particular family"
#   value       = aws_ecs_task_definition.this.revision
# }
