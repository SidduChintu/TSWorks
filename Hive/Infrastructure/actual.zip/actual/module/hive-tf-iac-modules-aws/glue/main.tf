# ------------------------------------------------------------------------------
# Local variables & Constants
# ------------------------------------------------------------------------------

locals {
  final_resource_name = "${var.naming_convention_properties.project}-${var.naming_convention_properties.environment}"
  common_tags         = var.tags
}

# ------------------------------------------------------------------------------
# AWS Glue Catalog Database
# https://registry.terraform.io/providers/hashicorp/aws/5.87.0/docs/resources/glue_catalog_database
# This section creates AWS Glue Catalog Databases.
# It includes the creation of Glue Catalog Databases with properties such as name, description,
# location URI, parameters, and tags.
# ------------------------------------------------------------------------------

resource "aws_glue_catalog_database" "glue_catalog_database" {
  for_each = { for k, v in var.glue_catalog_database : k => v if lookup(v, "deploy", true) }

  name         = "${var.naming_convention_properties.project}-glue-catalog-${var.naming_convention_properties.environment}-${each.value.name}-db"
  catalog_id   = lookup(each.value, "catalog_id", null)
  description  = lookup(each.value, "description", null)
  location_uri = lookup(each.value, "location_uri", null)
  parameters   = lookup(each.value, "parameters", {})
  tags         = local.common_tags
  dynamic "create_table_default_permission" {
    for_each = each.value.create_table_default_permission != null ? each.value.create_table_default_permission : []
    content {
      permissions = create_table_default_permission.value.permissions
      principal {
        data_lake_principal_identifier = create_table_default_permission.value.principal.data_lake_principal_identifier
      }
    }
  }


  dynamic "federated_database" {
    for_each = each.value.federated_database != null ? [each.value.federated_database] : []
    content {
      connection_name = federated_database.value.connection_name
      identifier      = federated_database.value.identifier
    }
  }

  dynamic "target_database" {
    for_each = each.value.target_database != null ? [each.value.target_database] : []
    content {
      catalog_id    = target_database.value.catalog_id
      database_name = target_database.value.database_name
      region        = target_database.value.region
    }
  }
}

# ------------------------------------------------------------------------------
# Glue Connection
# https://registry.terraform.io/providers/hashicorp/aws/5.87.0/docs/resources/glue_connection
# This section creates AWS Glue Connections.
# It includes the creation of Glue Connections with properties such as connection type,
# description, connection properties, and physical connection requirements.
# The connections can be used for various data sources such as JDBC, S3, etc.
# ------------------------------------------------------------------------------

resource "aws_glue_connection" "glue_connection" {
  for_each = { for k, v in var.connections : k => v if lookup(v, "deploy", true) }

  name                  = "${var.naming_convention_properties.project}-glue-con-${var.naming_convention_properties.environment}-${each.value.name}"
  connection_type       = each.value.connection_type
  description           = lookup(each.value, "description", null)
  tags                  = local.common_tags
  connection_properties = each.value.connection_properties

  dynamic "physical_connection_requirements" {
    for_each = each.value.physical_connection_requirements != null ? [each.value.physical_connection_requirements] : []
    content {
      availability_zone      = lookup(physical_connection_requirements.value, "availability_zone", null)
      security_group_id_list = lookup(physical_connection_requirements.value, "security_group_id_list", [])
      subnet_id              = lookup(physical_connection_requirements.value, "subnet_id", null)
    }
  }
}

# ------------------------------------------------------------------------------
# Glue Security Configuration
# https://registry.terraform.io/providers/hashicorp/aws/5.87.0/docs/resources/glue_security_configuration
# This section creates AWS Glue Security Configurations.
# It includes the creation of Glue Security Configurations with properties such as encryption configurations
# for CloudWatch, job bookmarks, and S3.
# The security configurations are used to secure data in Glue jobs and crawlers.
# ------------------------------------------------------------------------------

resource "aws_glue_security_configuration" "glue_security_configuration" {
  for_each = { for k, v in var.security_configurations : k => v if lookup(v, "deploy", true) }

  name = "${var.naming_convention_properties.project}-glue-securityconfig-${var.naming_convention_properties.environment}-${each.value.name}"

  encryption_configuration {
    cloudwatch_encryption {
      cloudwatch_encryption_mode = each.value.encryption_configuration.cloudwatch_encryption.cloudwatch_encryption_mode
      kms_key_arn                = lookup(each.value.encryption_configuration.cloudwatch_encryption, "kms_key_arn", null)
    }

    job_bookmarks_encryption {
      job_bookmarks_encryption_mode = each.value.encryption_configuration.job_bookmarks_encryption.job_bookmarks_encryption_mode
      kms_key_arn                   = lookup(each.value.encryption_configuration.job_bookmarks_encryption, "kms_key_arn", null)
    }

    s3_encryption {
      s3_encryption_mode = each.value.encryption_configuration.s3_encryption.s3_encryption_mode
      kms_key_arn        = lookup(each.value.encryption_configuration.s3_encryption, "kms_key_arn", null)
    }
  }
}