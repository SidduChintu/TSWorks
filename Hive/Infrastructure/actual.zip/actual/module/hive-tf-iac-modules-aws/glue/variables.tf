# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

# ------------------------------------------------------------------------------
# Glue Connections Variables
# This section defines the variables required for creating AWS Glue Connections.
# It includes connection configurations such as connection type, description,
# connection properties, and physical connection requirements.
# The `connections` variable is a map where each key corresponds to a connection name and
# the value is an object containing the connection's properties.
# ------------------------------------------------------------------------------

variable "connections" {
  description = "Map of Glue Connections"
  type = map(object({
    deploy                = optional(bool, true)
    name                  = string
    connection_type       = string
    description           = optional(string)
    tags                  = optional(map(string))
    connection_properties = map(string)

    physical_connection_requirements = optional(object({
      availability_zone      = optional(string)
      security_group_id_list = optional(list(string))
      subnet_id              = optional(string)
    }))
  }))
  default = {}
}

# ------------------------------------------------------------------------------
# Glue Security Configurations Variables
# This section defines the variables required for creating AWS Glue Security Configurations.
# It includes security configurations such as encryption configurations for CloudWatch,
# job bookmarks, and S3.
# The `security_configurations` variable is a map where each key corresponds to a security configuration
# name and the value is an object containing the security configuration's properties.
# ------------------------------------------------------------------------------

variable "security_configurations" {
  description = "Map of Glue Security Configurations"
  type = map(object({
    deploy = optional(bool, true)
    name   = string
    encryption_configuration = object({
      cloudwatch_encryption = object({
        cloudwatch_encryption_mode = string
        kms_key_arn                = optional(string)
      })
      job_bookmarks_encryption = object({
        job_bookmarks_encryption_mode = string
        kms_key_arn                   = optional(string)
      })
      s3_encryption = object({
        s3_encryption_mode = string
        kms_key_arn        = optional(string)
      })
    })
  }))
  default = {}
}

# ------------------------------------------------------------------------------
# Glue Catalog Database Variables
# This section defines the variables required for creating AWS Glue Catalog Databases.
# It includes database configurations such as name, catalog ID, description,
# location URI, parameters, tags, and optional properties for create table default permissions,
# federated databases, and target databases.
# The `glue_catalog_database` variable is a map where each key corresponds to a database name and
# the value is an object containing the database's properties.
# ------------------------------------------------------------------------------

variable "glue_catalog_database" {
  description = "Map of Glue Catalog Databases"
  type = map(object({
    deploy       = optional(bool, true)
    name         = string
    catalog_id   = optional(string)
    description  = optional(string)
    location_uri = optional(string)
    parameters   = optional(map(string))
    tags         = optional(map(string))

    create_table_default_permission = optional(list(object({
      permissions = list(string)
      principal = object({
        data_lake_principal_identifier = string
      })
    })))

    federated_database = optional(object({
      connection_name = string
      identifier      = string
    }))

    target_database = optional(object({
      catalog_id    = string
      database_name = string
      region        = string
    }))
  }))
  default = {}
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}