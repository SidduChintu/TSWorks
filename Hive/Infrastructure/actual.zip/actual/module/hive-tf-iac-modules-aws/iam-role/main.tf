# ------------------------------------------------------------------------------
# Local variables & Constants
# ------------------------------------------------------------------------------

locals {
  common_tags = var.tags
}

# ------------------------------------------------------------------------------
# AWS IAM Role and Policy Management
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role
# This section creates IAM roles and policies based on the provided configurations.
# It includes the creation of IAM roles with assume role policies, managed policy attachments,
# inline policies, and the necessary tags.
# ------------------------------------------------------------------------------

resource "aws_iam_role" "this" {
  for_each = var.iam_roles

  name                 = "${var.naming_convention_properties.project}-iamrole-${var.naming_convention_properties.environment}-${each.key}-role"
  description          = lookup(each.value, "description", null)
  path                 = lookup(each.value, "path", "/")
  max_session_duration = lookup(each.value, "max_session_duration", 3600)
  assume_role_policy   = each.value.assume_role_policy
  tags                 = local.common_tags
}


# ------------------------------------------------------------------------------
# IAM Role Policy Attachment
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment
# This section attaches managed policies to the IAM roles created above.
# It uses the `aws_iam_role_policy_attachment` resource to associate each role with its managed policies.
# ------------------------------------------------------------------------------

resource "aws_iam_role_policy_attachment" "this" {
  for_each = { for pair in flatten([
    for role_name, role in var.iam_roles : [
      for policy in role.managed_policies : {
        role_name  = role_name
        policy_arn = policy
      }
    ]
  ]) : "${pair.role_name}-${pair.policy_arn}" => pair }

  role       = aws_iam_role.this[each.value.role_name].name
  policy_arn = each.value.policy_arn
}

# ------------------------------------------------------------------------------
# IAM Inline Policies
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy
# This section creates inline policies for the IAM roles defined above.
# It uses the `aws_iam_role_policy` resource to define policies directly associated with each role.
# Each inline policy is defined by its name and policy document, which is provided in the `inline_policies` map of the `iam_roles` variable.
# ------------------------------------------------------------------------------

resource "aws_iam_role_policy" "this" {
  for_each = { for pair in flatten([
    for role_name, role in var.iam_roles : [
      for policy_name, policy in role.inline_policies : {
        role_name   = role_name
        policy_name = policy_name
        policy_doc  = policy.policy
      }
    ]
  ]) : "${pair.role_name}-${pair.policy_name}" => pair }

  name   = "${var.naming_convention_properties.project}-iampolicy-${var.naming_convention_properties.environment}-${each.value.policy_name}-policy"
  role   = aws_iam_role.this[each.value.role_name].name
  policy = each.value.policy_doc
}