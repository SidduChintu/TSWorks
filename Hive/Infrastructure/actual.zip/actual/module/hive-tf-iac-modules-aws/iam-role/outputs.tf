# ------------------------------------------------------------------------------
# IAM Role Outputs
#
# USAGE EXAMPLES:
# All outputs can be referenced in other modules using: module.iam.<output_name>
# ------------------------------------------------------------------------------

output "iam_roles" {
  description = "Map of all created IAM roles with their ID, ARN, and name attributes"
  value = {
    for role in aws_iam_role.this :
    role.name => {
      id   = role.id
      arn  = role.arn
      name = role.name
    }
  }
  # Example usage:
  # - module.iam.iam_roles["MyRoleName"].arn
  # - Use when referencing IAM roles in other resources or policies
  #
  # Common applications:
  # 1. Attaching policies to roles: aws_iam_role_policy_attachment.this.role = module.iam.iam_roles["MyRoleName"].name
  # 2. Assuming roles in other services: resource "aws_lambda_function" "this" { role = module.iam.iam_roles["LambdaRole"].arn }
  # 3. Cross-account access: In IAM policies using the role ARN
}