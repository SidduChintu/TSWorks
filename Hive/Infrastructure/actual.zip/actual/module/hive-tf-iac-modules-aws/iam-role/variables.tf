# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

# ------------------------------------------------------------------------------
# IAM Roles Variables
# This section defines the variables required for creating AWS IAM roles.
# It includes role configurations such as name, description, path, max session duration,
# assume role policy, managed policies, inline policies, and tags.
# The `iam_roles` variable is a map where each key corresponds to a role name and
# the value is an object containing the role's properties.
# ------------------------------------------------------------------------------

variable "iam_roles" {
  description = "Map of IAM roles with their policies"
  type = map(object({
    description          = optional(string)
    path                 = optional(string, "/")
    max_session_duration = optional(number, 3600)
    assume_role_policy   = string
    managed_policies     = optional(list(string), [])
    inline_policies = optional(map(object({
      policy = string
    })), {})
  }))
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}