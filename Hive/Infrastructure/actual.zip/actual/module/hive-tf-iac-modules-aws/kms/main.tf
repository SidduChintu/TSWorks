# ------------------------------------------------------------------------------
# AWS KMS Key Management Module
# This module creates AWS KMS keys and aliases based on the provided configurations.
# It allows for customization of key properties such as description, deletion window,
# key usage, and customer master key specification.
# ------------------------------------------------------------------------------
data "aws_caller_identity" "current" {}

resource "aws_kms_key" "this" {
  for_each = var.kms_keys

  description             = each.value.description
  deletion_window_in_days = each.value.deletion_window_in_days
  enable_key_rotation     = each.value.enable_key_rotation
  is_enabled              = each.value.is_enabled
  multi_region            = each.value.multi_region
  policy                  = each.value.policy != null ? each.value.policy : data.aws_iam_policy_document.default[each.key].json

  # Key specifications
  key_usage                = each.value.key_usage
  customer_master_key_spec = each.value.customer_master_key_spec

  # Advanced options
  bypass_policy_lockout_safety_check = each.value.bypass_policy_lockout_safety_check

  tags = merge(var.tags, { "Name" = format("%s-kms-%s-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment, each.value.key_name) }, each.value.tags)
}

resource "aws_kms_alias" "this" {
  for_each = { for k, v in var.kms_keys : k => v if v.alias != null }

  name          = "alias/${var.naming_convention_properties.project}-kms-${var.naming_convention_properties.environment}-${each.value.alias}"
  target_key_id = aws_kms_key.this[each.key].key_id
}

data "aws_iam_policy_document" "default" {
  for_each = var.kms_keys

  statement {
    sid    = "Enable IAM User Permissions"
    effect = "Allow"
    principals {
      type        = "AWS"
      identifiers = ["arn:aws:iam::${data.aws_caller_identity.current.account_id}:root"]
    }
    actions   = ["kms:*"]
    resources = ["*"]
  }

  dynamic "statement" {
    for_each = each.value.additional_policy_statements != null ? each.value.additional_policy_statements : []
    content {
      sid       = statement.value.sid
      effect    = statement.value.effect
      actions   = statement.value.actions
      resources = statement.value.resources

      principals {
        type        = statement.value.principal.type
        identifiers = statement.value.principal.identifiers
      }

      dynamic "condition" {
        for_each = statement.value.condition != null ? [statement.value.condition] : []
        content {
          test     = condition.value.test
          variable = condition.value.variable
          values   = condition.value.values
        }
      }
    }
  }
}