# ------------------------------------------------------------------------------
# KMS Key Outputs
#
# USAGE EXAMPLES:
# All outputs can be referenced in other modules using: module.kms.<output_name>
# ------------------------------------------------------------------------------

output "kms_keys" {
  description = "Comprehensive map of all created KMS keys with their full attributes including ID, ARN, configuration, and metadata"
  value = {
    for key_name, key in aws_kms_key.this : key_name => {
      id           = key.id
      arn          = key.arn
      key_id       = key.key_id
      description  = key.description
      enabled      = key.is_enabled
      key_rotation = key.enable_key_rotation
      multi_region = key.multi_region
      key_usage    = key.key_usage
      key_spec     = key.customer_master_key_spec
      policy       = key.policy
      tags         = key.tags
    }
  }
  # Example usage:
  # - module.kms.kms_keys["my_key"].arn
  # - Use when needing complete key configuration details
}

output "kms_key_aliases" {
  description = "Map of all KMS key aliases with their target key references and ARNs"
  value = {
    for alias_name, alias in aws_kms_alias.this : alias_name => {
      name           = alias.name
      target_key     = alias.target_key_id
      target_key_arn = aws_kms_key.this[alias_name].arn
    }
  }
  # Example usage:
  # - module.kms.kms_key_aliases["my_alias"].target_key_arn
  # - Use when referencing keys by their alias names
}

output "kms_key_arns" {
  description = "Simplified map of KMS key ARNs keyed by their Terraform resource names"
  value = {
    for key_name, key in aws_kms_key.this : key_name => key.arn
  }
  # Example usage:
  # - module.kms.kms_key_arns["my_key"]
  # - Use when only the ARN is needed for IAM policies or resource references
}

output "kms_key_ids" {
  description = "Map of KMS key IDs (UUID format) keyed by their Terraform resource names"
  value = {
    for key_name, key in aws_kms_key.this : key_name => key.key_id
  }
  # Example usage:
  # - module.kms.kms_key_ids["my_key"]
  # - Use when referencing keys in API calls or CLI commands
}

output "kms_key_policies" {
  description = "Map of raw IAM policy documents attached to each KMS key"
  value = {
    for key_name, key in aws_kms_key.this : key_name => key.policy
  }
  # Example usage:
  # - module.kms.kms_key_policies["my_key"]
  # - Use for policy analysis or when creating similar policies
}

output "default_policy_documents" {
  description = "Map of generated default IAM policy documents in JSON format for each KMS key"
  value = {
    for key_name, policy in data.aws_iam_policy_document.default : key_name => policy.json
  }
  # Example usage:
  # - module.kms.default_policy_documents["my_key"]
  # - Use when needing the default policy JSON for reference or modification
}