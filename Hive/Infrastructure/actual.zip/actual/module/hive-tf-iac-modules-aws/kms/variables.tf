# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

# ------------------------------------------------------------------------------
# KMS Keys Variables
# This section defines the variables required for creating AWS KMS keys.
# It includes key configurations such as key name, description, alias, policy,
# deletion window, key usage, customer master key specification, and advanced options.
# It also allows for additional policy statements and tags.
# ------------------------------------------------------------------------------

variable "kms_keys" {
  description = "Map of KMS keys to create"
  type = map(object({
    key_name    = string
    description = string
    alias       = optional(string)
    policy      = optional(string) # Path to policy JSON file

    # Key configuration
    deletion_window_in_days = optional(number, 30)
    enable_key_rotation     = optional(bool, true)
    is_enabled              = optional(bool, true)
    multi_region            = optional(bool, false)

    # Key specifications
    key_usage                = optional(string, "ENCRYPT_DECRYPT")
    customer_master_key_spec = optional(string, "SYMMETRIC_DEFAULT")

    # Advanced options
    bypass_policy_lockout_safety_check = optional(bool, false)

    # Additional policy statements
    additional_policy_statements = optional(list(object({
      sid       = string
      effect    = string
      actions   = list(string)
      resources = list(string)
      principal = object({
        type        = string
        identifiers = list(string)
      })
      condition = optional(object({
        test     = string
        variable = string
        values   = list(string)
      }))
    })), [])

    # Tags
    tags = optional(map(string), {})
  }))
}

variable "tags" {
  description = "Common tags for all resources"
  type        = map(string)
  default     = {}
}