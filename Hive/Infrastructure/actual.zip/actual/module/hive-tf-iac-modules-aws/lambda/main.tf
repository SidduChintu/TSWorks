# ------------------------------------------------------------------------------
# Local variables & Constants
# ------------------------------------------------------------------------------

locals {
  lambda_managed_policy_attachments = flatten([
    for lambda_key, lambda in var.lambda_functions : [
      for policy_arn in lambda.managed_policies : {
        lambda_key = lambda_key
        policy_arn = policy_arn
      }
    ]
  ])

  lambda_inline_policies = flatten([
    for lambda_key, lambda in var.lambda_functions : [
      for policy_name, policy_obj in lambda.inline_policies : {
        lambda_key  = lambda_key
        policy_name = policy_name
        policy_json = policy_obj.policy
      }
    ]
  ])
}

# ------------------------------------------------------------------------------
# AWS Data Sources
# Default assume role policy
# ------------------------------------------------------------------------------

data "aws_iam_policy_document" "default_assume_role" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

# ------------------------------------------------------------------------------
# AWS Lambda IAM Role and Function
# This section creates IAM roles and policies for AWS Lambda functions.
# It includes the creation of IAM roles with assume role policies, managed policy attachments,
# inline policies, and the Lambda functions themselves.
# Each Lambda function is configured with properties such as handler, runtime, memory size,
# timeout, environment variables, VPC configuration, and tags.
# ------------------------------------------------------------------------------

resource "aws_iam_role" "lambda_role" {
  for_each = var.lambda_functions

  name               = "${var.naming_convention_properties.project}-iamrole-${var.naming_convention_properties.environment}-${each.key}-lambda-role"
  assume_role_policy = each.value.assume_role_policy != "" ? each.value.assume_role_policy : data.aws_iam_policy_document.default_assume_role.json
  tags = merge(
    {
      Name = "${var.naming_convention_properties.project}-iamrole-${var.naming_convention_properties.environment}-${each.key}-lambda-role"
    },
    each.value.tags,
    var.tags
  )
}

# Attach managed policies
resource "aws_iam_role_policy_attachment" "managed" {
  for_each = {
    for idx, attachment in local.lambda_managed_policy_attachments :
    "${attachment.lambda_key}-${md5(attachment.policy_arn)}" => attachment
  }

  role       = aws_iam_role.lambda_role[each.value.lambda_key].name
  policy_arn = each.value.policy_arn
}

# Attach inline policies
resource "aws_iam_role_policy" "inline" {
  for_each = {
    for p in local.lambda_inline_policies :
    "${p.lambda_key}-${p.policy_name}" => p
  }

  name   = "${var.naming_convention_properties.project}-iampolicy-${var.naming_convention_properties.environment}-${each.key}"
  role   = aws_iam_role.lambda_role[each.value.lambda_key].id
  policy = each.value.policy_json
}

# Lambda Function
resource "aws_lambda_function" "this" {
  for_each      = var.lambda_functions
  function_name = "${var.naming_convention_properties.project}-lambda-${var.naming_convention_properties.environment}-${each.key}"
  description   = each.value.description
  handler       = each.value.handler
  runtime       = each.value.runtime
  role          = aws_iam_role.lambda_role[each.key].arn
  memory_size   = each.value.memory_size
  timeout       = each.value.timeout
  publish       = each.value.publish

  filename         = try(each.value.filename, null)
  source_code_hash = try(filebase64sha256(each.value.filename), null)

  dynamic "environment" {
    for_each = each.value.environment_variables != null && !each.value.ignore_code_and_env ? [1] : []
    content {
      variables = each.value.environment_variables
    }
  }

  dynamic "vpc_config" {
    for_each = each.value.vpc_config != null ? [1] : []
    content {
      subnet_ids         = each.value.vpc_config.subnet_ids
      security_group_ids = each.value.vpc_config.security_group_ids
    }
  }

  lifecycle {
    ignore_changes = [
      filename,
      source_code_hash,
      environment,
    ]
  }

  tags = merge(
    {
      Name = "${var.naming_convention_properties.project}-lambda-${var.naming_convention_properties.environment}-${each.key}"
    },
    each.value.tags,
    var.tags
  )
}

# CloudWatch Log Group
resource "aws_cloudwatch_log_group" "lambda" {
  for_each          = var.lambda_functions
  name              = "/aws/lambda/${aws_lambda_function.this[each.key].function_name}"
  retention_in_days = each.value.log_retention_in_days
  tags = merge(
    {
      Name = "${var.naming_convention_properties.project}-lg-${var.naming_convention_properties.environment}-${each.key}"
    },
    each.value.tags,
    var.tags
  )
}
