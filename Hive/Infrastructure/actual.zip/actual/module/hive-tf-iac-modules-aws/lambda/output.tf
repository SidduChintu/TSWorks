# ------------------------------------------------------------------------------
# Lambda Function Outputs
#
# USAGE EXAMPLES:
# All outputs can be referenced in other modules using: module.lambda.<output_name>
# ------------------------------------------------------------------------------

output "lambda_function_arns" {
  description = "Map of Lambda function names to their ARNs"
  value = {
    for k, v in aws_lambda_function.this : k => v.arn
  }
  # Example usage:
  # - module.lambda.lambda_function_arns["my_function"]
  # - Use when referencing Lambda ARNs in other resources
}

output "lambda_functions" {
  description = "Detailed map of Lambda function information including ARNs, qualified ARNs, invoke ARNs, IAM roles, and CloudWatch log groups"
  value = {
    for k, v in aws_lambda_function.this : k => {
      arn           = v.arn
      qualified_arn = v.qualified_arn
      invoke_arn    = v.invoke_arn
      role_arn      = aws_iam_role.lambda_role[k].arn
      log_group     = aws_cloudwatch_log_group.lambda[k].name
      function_name = v.function_name
    }
  }
  # Example usage:
  # - module.lambda.lambda_functions["my_function"].invoke_arn
  # - Use when needing comprehensive Lambda function details
}

output "lambda_roles" {
  description = "Map of Lambda IAM role ARNs"
  value = {
    for k, v in aws_iam_role.lambda_role : k => v.arn
  }
  # Example usage:
  # - module.lambda.lambda_roles["my_function"]
  # - Use when referencing Lambda execution roles in IAM policies
}

output "lambda_arns" {
  description = "Map of Lambda function names to their ARNs (keyed by function name)"
  value = {
    for lambda_key, lambda in aws_lambda_function.this :
    lambda.function_name => lambda.arn
  }
  # Example usage:
  # - module.lambda.lambda_arns["my-function-name"]
  # - Use when referencing Lambda ARNs by their actual function name
}

output "lambda_arns_by_key" {
  description = "Map of Lambda ARNs (keyed by Terraform resource key)"
  value = {
    for lambda_key, lambda in aws_lambda_function.this :
    lambda_key => lambda.arn
  }
  # Example usage:
  # - module.lambda.lambda_arns_by_key["my_function"]
  # - Use when referencing Lambda ARNs by their Terraform identifier
}