# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

# ------------------------------------------------------------------------------
# Lambda Functions Variables
# This section defines the variables required for creating AWS Lambda functions.
# It includes function configurations such as handler, runtime, memory size, timeout,
# environment variables, VPC configuration, tags, and IAM role policies.
# The variables also allow for customization of IAM roles, including assume role policies,
# managed policies, and inline policies.
# Additionally, it provides an option to ignore code and environment variables from Terraform.
# ------------------------------------------------------------------------------

variable "lambda_functions" {
  description = "Map of Lambda functions with their config, including role policies"
  type = map(object({
    description           = string
    handler               = string
    runtime               = string
    memory_size           = number
    timeout               = number
    publish               = bool
    filename              = optional(string)
    environment_variables = optional(map(string), {})
    vpc_config = optional(object({
      subnet_ids         = list(string)
      security_group_ids = list(string)
    }), null)
    tags                  = optional(map(string), {})
    log_retention_in_days = number

    # New for IAM Role customization:
    assume_role_policy = optional(string, "")
    managed_policies   = optional(list(string), ["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"])
    inline_policies    = optional(map(object({ policy = string })), {}) # map of name -> { policy = file path }

    # Optional flag to ignore code/env from Terraform
    ignore_code_and_env = optional(bool, true)
  }))
}

variable "tags" {
  description = "Common tags for all resources"
  type        = map(string)
  default     = {}
}
