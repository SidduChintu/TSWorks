# ------------------------------------------------------------------------------
# Local variables & Constants
# ------------------------------------------------------------------------------

locals {
  rds_cluster_engine                              = var.rds_cluster_engine
  rds_cluster_engine_mode                         = "provisioned"
  rds_cluster_storage_encrypted                   = true
  rds_cluster_manage_master_user_password         = true
  rds_cluster_allow_major_version_upgrade         = false
  rds_cluster_apply_immediately                   = true
  rds_cluster_deletion_protection                 = false
  rds_cluster_instance_class                      = "db.serverless"
  rds_cluster_instance_publicly_accessible        = false
  rds_cluster_iam_database_authentication_enabled = true
  rds_cluster_instance_auto_minor_version_upgrade = false
  common_tags                                     = var.tags
}

# ------------------------------------------------------------------------------
# AWS Data Sources
# ------------------------------------------------------------------------------

data "aws_partition" "current" {}

# ------------------------------------------------------------------------------
# AWS RDS Aurora Postgres Cluster
# This section creates an AWS RDS Aurora Postgres cluster with the specified configurations.
# It includes the creation of a database subnet group, security group, and the RDS cluster itself.
# The cluster is configured with various parameters such as engine version, storage encryption,
# master username, and scaling configurations.
# The cluster instances are created with monitoring and performance insights enabled.
# ------------------------------------------------------------------------------

resource "aws_db_subnet_group" "db_subnet_group" {
  name        = "${var.naming_convention_properties.project}-dbsubnetgroup-${var.naming_convention_properties.environment}-${var.db_subnet_group_name}"
  description = "This is RDS Aurora Postgres Database Subnet Group for ${var.naming_convention_properties.environment} Envrionment."
  subnet_ids  = var.db_subnet_group_subnet_ids
}

resource "aws_security_group" "rds_cluster_security_group" {
  name        = "${var.naming_convention_properties.project}-sg-${var.naming_convention_properties.environment}-${var.rds_cluster_security_group_name}"
  description = "This is RDS Aurora Postgres Database Security Group for ${var.naming_convention_properties.environment} Envrionment."
  vpc_id      = var.vpc_id

  dynamic "ingress" {
    for_each = var.rds_security_group_ingress_rules
    content {
      from_port   = ingress.value.from_port
      to_port     = ingress.value.to_port
      protocol    = ingress.value.protocol
      cidr_blocks = ingress.value.cidr_blocks
      description = lookup(ingress.value, "description", null)
    }
  }

  dynamic "egress" {
    for_each = var.rds_security_group_egress_rules
    content {
      from_port   = egress.value.from_port
      to_port     = egress.value.to_port
      protocol    = egress.value.protocol
      cidr_blocks = egress.value.cidr_blocks
      description = lookup(egress.value, "description", null)
    }
  }

  tags = merge(local.common_tags, {
    "Name" = format("%s-sg-%s-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment, var.rds_cluster_security_group_name)
  })
}

resource "aws_rds_cluster" "rds_cluster" {
  cluster_identifier                  = "${var.naming_convention_properties.project}-rdsaurora-${var.naming_convention_properties.environment}-${var.rds_cluster_identifier}"
  database_name                       = var.rds_cluster_database_name
  engine                              = local.rds_cluster_engine
  engine_mode                         = local.rds_cluster_engine_mode
  engine_version                      = var.rds_cluster_engine_version
  storage_encrypted                   = local.rds_cluster_storage_encrypted
  master_username                     = var.rds_cluster_master_username
  manage_master_user_password         = local.rds_cluster_manage_master_user_password
  allow_major_version_upgrade         = local.rds_cluster_allow_major_version_upgrade
  apply_immediately                   = local.rds_cluster_apply_immediately
  deletion_protection                 = local.rds_cluster_deletion_protection
  availability_zones                  = var.rds_cluster_availability_zones
  backup_retention_period             = var.rds_cluster_backup_retention_period
  iam_database_authentication_enabled = local.rds_cluster_iam_database_authentication_enabled
  vpc_security_group_ids              = [aws_security_group.rds_cluster_security_group.id]
  db_subnet_group_name                = aws_db_subnet_group.db_subnet_group.name
  enabled_cloudwatch_logs_exports     = var.rds_cluster_enabled_cloudwatch_logs_exports
  skip_final_snapshot                 = var.rds_skip_final_snapshot

  serverlessv2_scaling_configuration {
    max_capacity = var.rds_cluster_serverlessv2_scaling_configuration.max_capacity
    min_capacity = var.rds_cluster_serverlessv2_scaling_configuration.min_capacity
  }
  lifecycle {
    ignore_changes = [
      availability_zones,
      backup_retention_period,
      tags,
    ]
  }
  tags = merge(local.common_tags, {
    "Name" = format("%s-rdsaurora-%s-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment, var.rds_cluster_identifier)
  })
}

data "aws_iam_policy_document" "rds_enhanced_monitoring_assume_role_policy" {
  count = var.rds_cluster_instance_enable_enhanced_monitoring ? 1 : 0

  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["monitoring.rds.${data.aws_partition.current.dns_suffix}"]
    }
  }
}

resource "aws_iam_role" "rds_enhanced_monitoring_iam_role" {
  count              = var.rds_cluster_instance_enable_enhanced_monitoring ? 1 : 0
  name               = "${var.naming_convention_properties.project}-iamrole-${var.naming_convention_properties.environment}-${var.rds_enhanced_monitoring_iam_role_name}"
  description        = var.rds_enhanced_monitoring_iam_role_description
  path               = var.rds_enhanced_monitoring_iam_role_path
  assume_role_policy = data.aws_iam_policy_document.rds_enhanced_monitoring_assume_role_policy[0].json
  lifecycle {
    ignore_changes = [
      assume_role_policy
    ]
  }
  tags = merge(local.common_tags, {
    "Name" = format("%s-iamrole-%s-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment, var.rds_enhanced_monitoring_iam_role_name)
  })
}

resource "aws_iam_role_policy_attachment" "rds_enhanced_monitoring_iam_role_policy_attachment" {
  count = var.rds_cluster_instance_enable_enhanced_monitoring ? 1 : 0

  role       = aws_iam_role.rds_enhanced_monitoring_iam_role[0].name
  policy_arn = "arn:${data.aws_partition.current.partition}:iam::aws:policy/service-role/AmazonRDSEnhancedMonitoringRole"
  lifecycle {
    ignore_changes = [
      policy_arn
    ]
  }
}

resource "aws_rds_cluster_instance" "rds_cluster_instance_write" {
  identifier                            = "${var.naming_convention_properties.project}-rdsaurora-${var.naming_convention_properties.environment}-${var.rds_cluster_identifier}db-001"
  cluster_identifier                    = aws_rds_cluster.rds_cluster.id
  instance_class                        = local.rds_cluster_instance_class
  engine                                = aws_rds_cluster.rds_cluster.engine
  engine_version                        = aws_rds_cluster.rds_cluster.engine_version
  monitoring_interval                   = var.rds_cluster_instance_monitoring_interval
  monitoring_role_arn                   = var.rds_cluster_instance_enable_enhanced_monitoring ? aws_iam_role.rds_enhanced_monitoring_iam_role[0].arn : null
  performance_insights_enabled          = var.rds_cluster_instance_performance_insights_enabled
  performance_insights_retention_period = var.rds_cluster_instance_performance_insights_retention_period
  auto_minor_version_upgrade            = local.rds_cluster_instance_auto_minor_version_upgrade
  tags = merge(local.common_tags, {
    "Name" = format("%s-rdsaurora-%s-%s-db-write", var.naming_convention_properties.project, var.naming_convention_properties.environment, var.rds_cluster_identifier)
  })
}

resource "aws_rds_cluster_instance" "rds_cluster_instance_read" {
  count                                 = var.create_rds_cluster_reader_instance ? 1 : 0
  identifier                            = "${var.naming_convention_properties.project}-rdsaurora-${var.naming_convention_properties.environment}-${var.rds_cluster_identifier}db-002"
  cluster_identifier                    = aws_rds_cluster.rds_cluster.id
  instance_class                        = local.rds_cluster_instance_class
  engine                                = aws_rds_cluster.rds_cluster.engine
  engine_version                        = aws_rds_cluster.rds_cluster.engine_version
  monitoring_interval                   = var.rds_cluster_instance_monitoring_interval
  monitoring_role_arn                   = var.rds_cluster_instance_enable_enhanced_monitoring ? aws_iam_role.rds_enhanced_monitoring_iam_role[0].arn : null
  performance_insights_enabled          = var.rds_cluster_instance_performance_insights_enabled
  performance_insights_retention_period = var.rds_cluster_instance_performance_insights_retention_period
  auto_minor_version_upgrade            = local.rds_cluster_instance_auto_minor_version_upgrade
  tags = merge(local.common_tags, {
    "Name" = format("%s-rdsaurora-%s-%s-db-read", var.naming_convention_properties.project, var.naming_convention_properties.environment, var.rds_cluster_identifier)
  })
}
