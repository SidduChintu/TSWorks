# ------------------------------------------------------------------------------
# RDS Aurora Cluster Outputs
#
# USAGE EXAMPLES:
# All outputs can be referenced in other modules using: module.rds.<output_name>
# ------------------------------------------------------------------------------

output "db_endpoint" {
  description = "The writer endpoint for the RDS Aurora cluster"
  value       = aws_rds_cluster.rds_cluster.endpoint
  # Example usage:
  # - module.rds.db_endpoint
  # - Use for application database connections
}

output "reader_endpoint" {
  description = "The reader endpoint for the RDS Aurora cluster"
  value       = aws_rds_cluster.rds_cluster.reader_endpoint
  # Example usage:
  # - module.rds.reader_endpoint
  # - Use for read-only database connections
}

output "db_name" {
  description = "The name of the database in the RDS Aurora cluster"
  value       = aws_rds_cluster.rds_cluster.database_name
  # Example usage:
  # - module.rds.db_name
  # - Use when configuring applications to connect to specific database
}

output "secret_arn" {
  description = "ARN of the master user secret for the RDS cluster"
  value       = local.rds_cluster_manage_master_user_password ? aws_rds_cluster.rds_cluster.master_user_secret[0].secret_arn : null
  # Example usage:
  # - module.rds.secret_arn
  # - Use for retrieving database credentials from Secrets Manager
}

output "rds_cluster_id" {
  description = "ID of the RDS Aurora cluster"
  value       = aws_rds_cluster.rds_cluster.id
  # Example usage:
  # - module.rds.rds_cluster_id
  # - Use for referencing the cluster in other resources
}

output "subnet_group_name" {
  description = "Name of the DB subnet group used by the cluster"
  value       = aws_db_subnet_group.db_subnet_group.name
  # Example usage:
  # - module.rds.subnet_group_name
  # - Use when managing subnet group configurations
}

output "subnet_group_id" {
  description = "ID of the DB subnet group"
  value       = aws_db_subnet_group.db_subnet_group.id
  # Example usage:
  # - module.rds.subnet_group_id
  # - Use for referencing the subnet group in other resources
}

output "security_group_id" {
  description = "ID of the security group associated with the RDS cluster"
  value       = aws_security_group.rds_cluster_security_group.id
  # Example usage:
  # - module.rds.security_group_id
  # - Use when modifying security group rules
}

output "monitoring_role_arn" {
  description = "IAM Role ARN for RDS Enhanced Monitoring (if created)"
  value       = var.rds_cluster_instance_enable_enhanced_monitoring ? aws_iam_role.rds_enhanced_monitoring_iam_role[0].arn : null
  # Example usage:
  # - module.rds.monitoring_role_arn
  # - Use for IAM policies requiring monitoring role ARN
}

output "instance_write_id" {
  description = "ID of the writer instance in the RDS cluster"
  value       = aws_rds_cluster_instance.rds_cluster_instance_write.id
  # Example usage:
  # - module.rds.instance_write_id
  # - Use for direct instance management
}

output "instance_read_id" {
  description = "ID of the reader instance in the RDS cluster"
  value       = var.create_rds_cluster_reader_instance ? aws_rds_cluster_instance.rds_cluster_instance_read[0].id : null
  # Example usage:
  # - module.rds.instance_read_id
  # - Use for direct instance management of read replicas
}