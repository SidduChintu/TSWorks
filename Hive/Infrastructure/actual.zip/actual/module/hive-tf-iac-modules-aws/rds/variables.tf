# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

# ------------------------------------------------------------------------------
# RDS Cluster Variables
# This section defines the variables required for creating an RDS cluster.
# It includes engine type, subnet group, security group, VPC ID, cluster identifier,
# database name, engine version, master username, availability zones, backup retention,
# scaling configuration, monitoring settings, and security group rules.
# ------------------------------------------------------------------------------

variable "rds_cluster_engine" {
  description = "RDS engine (aurora-mysql or aurora-postgresql)"
  type        = string
  default     = "aurora-postgresql"
}

variable "db_subnet_group_name" {
  description = "The name of the DB subnet group"
  type        = string
}

variable "db_subnet_group_subnet_ids" {
  description = "A list of subnet IDs for the DB subnet group"
  type        = list(string)
}

variable "rds_cluster_security_group_name" {
  description = "The name of the RDS cluster security group"
  type        = string
}

variable "vpc_id" {
  description = "The ID of the VPC"
  type        = string
}

variable "rds_cluster_identifier" {
  description = "The identifier for the RDS cluster"
  type        = string
}

variable "rds_cluster_database_name" {
  description = "The name of the default database in the RDS cluster"
  type        = string
  default     = null
}

variable "rds_cluster_engine_version" {
  description = "The engine version of the RDS cluster"
  type        = string
}

variable "rds_cluster_master_username" {
  description = "The master username for the RDS cluster"
  type        = string
  default     = "root"
}
variable "rds_cluster_availability_zones" {
  description = "A list of availability zones for the RDS cluster"
  type        = list(string)
}

variable "rds_cluster_backup_retention_period" {
  description = "The backup retention period for the RDS cluster"
  type        = number
  default     = 7
}

variable "rds_cluster_serverlessv2_scaling_configuration" {
  description = "Configuration for serverlessv2 scaling"
  type = object({
    max_capacity = number
    min_capacity = number
  })
}

variable "rds_cluster_instance_enable_enhanced_monitoring" {
  description = "Whether enhanced monitoring should be enabled for RDS instances"
  type        = bool
}

variable "rds_enhanced_monitoring_iam_role_name" {
  description = "The name of the IAM role for enhanced monitoring"
  type        = string
}

variable "rds_enhanced_monitoring_iam_role_description" {
  description = "The description of the IAM role for enhanced monitoring"
  type        = string
  default     = ""
}

variable "rds_enhanced_monitoring_iam_role_path" {
  description = "The path of the IAM role for enhanced monitoring"
  type        = string
  default     = "/"
}

variable "rds_cluster_instance_monitoring_interval" {
  description = "The monitoring interval for RDS instances"
  type        = number
  default     = 60
}

variable "rds_cluster_instance_performance_insights_enabled" {
  description = "Whether Performance Insights should be enabled for RDS instances"
  type        = bool
  default     = false
}

variable "rds_cluster_instance_performance_insights_retention_period" {
  description = "The retention period for Performance Insights data for RDS instances"
  type        = number
}

variable "rds_cluster_enabled_cloudwatch_logs_exports" {
  description = "An identifier for Read Database instance"
  type        = list(string)
  default     = ["general", "error"]
}

variable "create_rds_cluster_reader_instance" {
  description = "Whether to create a read-only replica instance"
  type        = bool
  default     = false
}

variable "rds_security_group_ingress_rules" {
  description = "List of ingress rules for RDS SG"
  type = list(object({
    from_port   = number
    to_port     = number
    protocol    = string
    cidr_blocks = list(string)
    description = optional(string)
  }))
}

variable "rds_security_group_egress_rules" {
  description = "List of egress rules for RDS SG"
  type = list(object({
    from_port   = number
    to_port     = number
    protocol    = string
    cidr_blocks = list(string)
    description = optional(string)
  }))
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}

variable "rds_skip_final_snapshot" {
  description = "Whether to skip final snapshot on RDS deletion"
  type        = bool
  default     = true
}
