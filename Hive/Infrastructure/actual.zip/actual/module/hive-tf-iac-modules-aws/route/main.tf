# ------------------------------------------------------------------------------
# Local variables & Constants
# ------------------------------------------------------------------------------

locals {
  resolved_routes_per_table = {
    for rt_name, routes in var.routes_per_table :
    rt_name => routes
    if contains(keys(var.route_table_name_to_id), rt_name)
  }

  flattened_routes = flatten([
    for rt_name, routes in local.resolved_routes_per_table : [
      for route in routes : {
        route_table_id = var.route_table_name_to_id[rt_name]
        route_key      = "${rt_name}-${route.destination_cidr_block != null ? route.destination_cidr_block : (route.destination_ipv6_cidr_block != null ? route.destination_ipv6_cidr_block : route.destination_prefix_list_id)}"
        route_data     = route
      }
    ]
  ])
}

# ------------------------------------------------------------------------------
# AWS Route Table Routes
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route
# This section creates routes in AWS route tables based on the provided configuration.
# Each route is associated with a specific route table and includes various routing options.
# The routes are defined in the `routes_per_table` variable, which maps route table names
# to their respective routes.
# ------------------------------------------------------------------------------

resource "aws_route" "route_table_routes" {
  for_each = {
    for r in local.flattened_routes : r.route_key => r
  }

  route_table_id = each.value.route_table_id

  destination_cidr_block      = lookup(each.value.route_data, "destination_cidr_block", null)
  destination_ipv6_cidr_block = lookup(each.value.route_data, "destination_ipv6_cidr_block", null)
  destination_prefix_list_id  = lookup(each.value.route_data, "destination_prefix_list_id", null)

  carrier_gateway_id        = lookup(each.value.route_data, "carrier_gateway_id", null)
  core_network_arn          = lookup(each.value.route_data, "core_network_arn", null)
  egress_only_gateway_id    = lookup(each.value.route_data, "egress_only_gateway_id", null)
  gateway_id                = lookup(each.value.route_data, "gateway_id", null)
  nat_gateway_id            = lookup(each.value.route_data, "nat_gateway_id", null)
  local_gateway_id          = lookup(each.value.route_data, "local_gateway_id", null)
  network_interface_id      = lookup(each.value.route_data, "network_interface_id", null)
  transit_gateway_id        = lookup(each.value.route_data, "transit_gateway_id", null)
  vpc_endpoint_id           = lookup(each.value.route_data, "vpc_endpoint_id", null)
  vpc_peering_connection_id = lookup(each.value.route_data, "vpc_peering_connection_id", null)
}
