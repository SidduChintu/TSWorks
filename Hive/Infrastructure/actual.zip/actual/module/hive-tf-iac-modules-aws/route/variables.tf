# ------------------------------------------------------------------------------
# Route Table Routes
# This section creates routes in AWS route tables based on the provided configuration.
# Each route is associated with a specific route table and includes various routing options.
# The routes are defined in the `routes_per_table` variable, which maps route table names
# to their respective routes.
# ------------------------------------------------------------------------------

variable "routes_per_table" {
  description = "Map of route table ID to list of route objects"
  type = map(list(object({
    # Destination
    destination_cidr_block      = optional(string)
    destination_ipv6_cidr_block = optional(string)
    destination_prefix_list_id  = optional(string)

    # Target
    carrier_gateway_id        = optional(string)
    core_network_arn          = optional(string)
    egress_only_gateway_id    = optional(string)
    gateway_id                = optional(string)
    nat_gateway_id            = optional(string)
    local_gateway_id          = optional(string)
    network_interface_id      = optional(string)
    transit_gateway_id        = optional(string)
    vpc_endpoint_id           = optional(string)
    vpc_peering_connection_id = optional(string)
  })))
}


variable "route_table_name_to_id" {
  description = "Map of route table name to its ID"
  type        = map(string)
}