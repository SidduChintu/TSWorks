# ------------------------------------------------------------------------------
# Local variables & Constants
# ------------------------------------------------------------------------------

locals {
  s3_buckets_config = {
    for k, v in var.s3_buckets :
    k => {
      bucket_name          = v.name
      s3_sse_algorithm     = lookup(v, "sse_algorithm", "AES256")
      kms_key_arn          = lookup(v, "kms_key_arn", null)
      s3_versioning_status = "Enabled"
      lifecycle_days       = lookup(v, "lifecycle_days", 30)
      policy               = lookup(v, "policy", null)
      event_notifications  = lookup(v, "event_notifications", [])
    }
  }
  common_tags = var.tags
  lambda_notifications = flatten([
    for bucket_key, bucket in var.s3_buckets : [
      for notification in bucket.event_notifications : {
        key           = "${bucket_key}-${notification.name}"
        function_name = notification.lambda_function_name
        bucket_key    = bucket_key
        notification  = notification
      } if notification.destination_type == "Lambda function"
    ]
  ])
}

# ------------------------------------------------------------------------------
# Data source to look up Lambda functions by name
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/lambda_function
# This data source retrieves information about existing Lambda functions that will be used for S3 bucket notifications
# ------------------------------------------------------------------------------

data "aws_lambda_function" "notification_lambda" {
  for_each = { for item in local.lambda_notifications : item.key => item }

  function_name = each.value.function_name
}

# ------------------------------------------------------------------------------
# S3 Bucket
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
# This section creates S3 buckets based on the configuration provided in the `s3_buckets` variable.
# Each bucket is named according to the naming convention properties and includes tags.
# The buckets are configured to allow force deletion and are tagged with common tags.
# ------------------------------------------------------------------------------

resource "aws_s3_bucket" "s3_bucket" {
  for_each = local.s3_buckets_config

  bucket        = "${var.naming_convention_properties.project}-s3-${var.naming_convention_properties.environment}-${each.value.bucket_name}"
  force_destroy = true
  tags          = local.common_tags
}

# ------------------------------------------------------------------------------
# S3 Server Side Encryption
# https://registry.terraform.io/providers/hashicorp/aws/5.86.1/docs/resources/s3_bucket_server_side_encryption_configuration
# This section configures server-side encryption for the S3 buckets created above.
# It applies the specified encryption algorithm and, if applicable, the KMS key for encryption.
# The configuration is based on the `s3_sse_algorithm` and `kms_key_arn` specified in the `s3_buckets` variable.
# ------------------------------------------------------------------------------

resource "aws_s3_bucket_server_side_encryption_configuration" "s3_bucket_sse" {
  for_each = local.s3_buckets_config

  bucket = aws_s3_bucket.s3_bucket[each.key].bucket

  rule {
    bucket_key_enabled = each.value.s3_sse_algorithm == "aws:kms" ? true : false

    apply_server_side_encryption_by_default {
      sse_algorithm     = each.value.s3_sse_algorithm
      kms_master_key_id = each.value.s3_sse_algorithm == "aws:kms" ? each.value.kms_key_arn : null
    }
  }
}

# ------------------------------------------------------------------------------
# S3 Bucket Versioning
# https://registry.terraform.io/providers/hashicorp/aws/5.86.1/docs/resources/s3_bucket_versioning
# This section enables versioning for the S3 buckets created above.
# Versioning is configured based on the `s3_versioning_status` specified in the `s3_buckets` variable.
# The versioning status is set to "Enabled" for each bucket.
# ------------------------------------------------------------------------------

resource "aws_s3_bucket_versioning" "s3_bucket_versioning" {
  for_each = local.s3_buckets_config

  bucket = aws_s3_bucket.s3_bucket[each.key].id

  versioning_configuration {
    status = each.value.s3_versioning_status
  }
}

# ------------------------------------------------------------------------------
# S3 Bucket Lifecycle Configuration
# https://registry.terraform.io/providers/hashicorp/aws/5.86.1/docs/resources/s3_bucket_lifecycle_configurationS
# This section configures lifecycle rules for the S3 buckets to manage object versions.
# It sets up a rule to expire non-current object versions after a specified number of days,
# which is defined in the `lifecycle_days` property of the `s3_buckets` variable.
# The rule is applied to each bucket that has versioning enabled.
# ------------------------------------------------------------------------------

resource "aws_s3_bucket_lifecycle_configuration" "s3_bucket_lifecycle" {
  for_each   = local.s3_buckets_config
  depends_on = [aws_s3_bucket_versioning.s3_bucket_versioning]

  bucket = aws_s3_bucket.s3_bucket[each.key].bucket

  rule {
    id = "expire-non-current-objects"
    noncurrent_version_expiration {
      noncurrent_days = each.value.lifecycle_days
    }
    status = "Enabled"
  }
}

# ------------------------------------------------------------------------------
# S3 Bucket Policy
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_policy
# This section applies a bucket policy to each S3 bucket that has a policy defined in the `s3_buckets` variable.
# The policy is specified in the `policy` property of the `s3_buckets` variable.
# The policy is applied to the bucket created above, allowing for fine-grained access control.
# ------------------------------------------------------------------------------

resource "aws_s3_bucket_policy" "s3_bucket_policy" {
  for_each = { for k, v in local.s3_buckets_config : k => v if v.policy != null }

  bucket = aws_s3_bucket.s3_bucket[each.key].id
  policy = each.value.policy
}

# ------------------------------------------------------------------------------
# S3 Bucket Notification
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket_notification
# This section configures event notifications for the S3 buckets.
# It sets up notifications for Lambda functions based on the `event_notifications` defined in the `s3_buckets` variable.
# Each notification is associated with a specific Lambda function and includes event types, filter prefixes, and suffixes.
# The notifications are created only for buckets that have defined event notifications.
# ------------------------------------------------------------------------------

resource "aws_s3_bucket_notification" "bucket_notification" {
  for_each = { for k, v in var.s3_buckets : k => v if length(v.event_notifications) > 0 }

  bucket = aws_s3_bucket.s3_bucket[each.key].id

  dynamic "lambda_function" {
    for_each = [
      for notification in each.value.event_notifications : {
        key          = "${each.key}-${notification.name}"
        notification = notification
      } if notification.destination_type == "Lambda function"
    ]

    content {
      lambda_function_arn = data.aws_lambda_function.notification_lambda[lambda_function.value.key].arn
      id                  = "${var.naming_convention_properties.project}-s3-event-${var.naming_convention_properties.environment}-${lambda_function.value.notification.name}"
      events              = lambda_function.value.notification.event_types
      filter_prefix       = lookup(lambda_function.value.notification, "filter_prefix", null)
      filter_suffix       = lookup(lambda_function.value.notification, "filter_suffix", null)
    }
  }

  lifecycle {
    ignore_changes = [lambda_function]
  }
}

# ------------------------------------------------------------------------------
# Lambda Permissions for S3 Bucket Notifications
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission
# This section grants permissions to the S3 bucket to invoke the specified Lambda functions.
# It creates a permission for each Lambda function that is configured to receive notifications from the S3 bucket.
# The permissions are set up to allow the S3 service to invoke the Lambda functions when the specified events occur in the bucket.
# The permissions are created based on the Lambda functions retrieved from the `data.aws_lambda_function.notification_lambda` data source.
# ------------------------------------------------------------------------------

resource "aws_lambda_permission" "allow_bucket" {
  for_each = data.aws_lambda_function.notification_lambda

  statement_id  = "AllowExecutionFromS3-${each.key}"
  action        = "lambda:InvokeFunction"
  function_name = each.value.function_name
  principal     = "s3.amazonaws.com"
  source_arn    = aws_s3_bucket.s3_bucket[split("-", each.key)[0]].arn
}
