# ------------------------------------------------------------------------------
# S3 Bucket Outputs
#
# USAGE EXAMPLES:
# All outputs can be referenced in other modules using: module.s3.<output_name>
# ------------------------------------------------------------------------------

output "s3_buckets" {
  description = "Map of created S3 bucket names to their IDs"
  value = {
    for key, bucket in aws_s3_bucket.s3_bucket : key => bucket.id
  }
  # Example usages:
  # - module.s3.s3_buckets["logs_bucket"]  # Get specific bucket ID by its key
  # - values(module.s3.s3_buckets)         # Get list of all bucket IDs
  # - keys(module.s3.s3_buckets)           # Get list of all bucket names/keys
  #
  # Common use cases:
  # 1. Reference in IAM policies needing bucket ARNs
  # 2. Configure other services to use these buckets
  # 3. Cross-account bucket access configurations
}

output "s3_bucket_names" {
  description = "Map of S3 bucket names created by the module"
  value = {
    for k, v in aws_s3_bucket.s3_bucket : k => v.bucket
  }
}

output "s3_bucket_arns" {
  description = "Map of S3 bucket ARNs created by the module"
  value = {
    for k, v in aws_s3_bucket.s3_bucket : k => v.arn
  }
}

output "s3_bucket_details" {
  description = "Map of all S3 bucket details created by the module"
  value = {
    for k, v in aws_s3_bucket.s3_bucket : k => {
      name = v.bucket
      arn  = v.arn
      id   = v.id
      tags = v.tags
    }
  }
}