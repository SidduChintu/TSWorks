# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

# ------------------------------------------------------------------------------
# S3 Bucket Variables
# This section defines the variables required for creating S3 buckets.
# It includes the S3 bucket configurations, such as name, server-side encryption settings,
# lifecycle rules, policies, and event notifications.
# These variables allow customization of the S3 bucket setup, including encryption methods,
# lifecycle management, and event-driven architectures using Lambda functions.
# ------------------------------------------------------------------------------

variable "s3_buckets" {
  description = "Map of S3 bucket configurations"
  type = map(object({
    name           = string
    sse_algorithm  = optional(string, "AES256")
    kms_key_arn    = optional(string)
    lifecycle_days = optional(number, 30)
    policy         = optional(string)
    event_notifications = optional(list(object({
      name                 = string
      event_types          = list(string)
      filter_prefix        = optional(string)
      filter_suffix        = optional(string)
      destination_type     = string
      lambda_function_name = string
    })), [])
  }))
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}
