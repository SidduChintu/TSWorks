# ------------------------------------------------------------------------------
# Local variables & Constants
# ------------------------------------------------------------------------------

locals {
  common_tags = var.tags
}

# ------------------------------------------------------------------------------
# Transit Gateway VPC Attachment
# This section defines the resource for creating a Transit Gateway VPC Attachment.
# It includes the VPC ID, subnet IDs, and Transit Gateway ID.
# The attachment is tagged with a name based on the naming convention properties.
# ------------------------------------------------------------------------------

resource "aws_ec2_transit_gateway_vpc_attachment" "this" {
  vpc_id             = var.vpc_id
  subnet_ids         = var.subnet_ids
  transit_gateway_id = var.transit_gateway_id

  tags = merge(local.common_tags, {
    "Name" = format("%s-tgwattachment-%s-vpc", var.naming_convention_properties.project, var.naming_convention_properties.environment)
  })
}
