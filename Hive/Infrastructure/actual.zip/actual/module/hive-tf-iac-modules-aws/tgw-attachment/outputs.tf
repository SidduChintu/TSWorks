# ------------------------------------------------------------------------------
# Transit Gateway VPC Attachment Outputs
#
# USAGE EXAMPLES:
# All outputs can be referenced in other modules using: module.vpc.<output_name>
# ------------------------------------------------------------------------------

output "attachment_id" {
  description = "The ID of the Transit Gateway VPC Attachment"
  value       = aws_ec2_transit_gateway_vpc_attachment.this.id
  # Example usage:
  # - module.vpc.attachment_id
  # - Use when you need to reference this specific VPC attachment in:
  #   * Route table associations
  #   * Security group rules
  #   * Monitoring configurations
  #   * Other resources that need to reference the attachment ID
}