# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

# ------------------------------------------------------------------------------
# Transit Gateway VPC Attachment Variables
# This section defines the variables required for creating a Transit Gateway VPC Attachment.
# It includes the VPC ID, subnet IDs, Transit Gateway ID, and tags.
# These variables allow customization of the Transit Gateway attachment setup,
# including the VPC to attach, the subnets to use, and the tags for resource management.
# ------------------------------------------------------------------------------

variable "vpc_id" {
  type        = string
  description = "VPC ID to attach to TGW"
}

variable "subnet_ids" {
  type        = list(string)
  description = "Subnet IDs in the VPC for TGW attachment"
}

variable "transit_gateway_id" {
  type        = string
  description = "Transit Gateway ID"
}

variable "tags" {
  type    = map(string)
  default = {}
}
