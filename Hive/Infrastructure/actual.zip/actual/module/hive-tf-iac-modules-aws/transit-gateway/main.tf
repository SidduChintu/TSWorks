# ------------------------------------------------------------------------------
# Local variables & Constants
# ------------------------------------------------------------------------------

locals {
  common_tags = var.tags
}

# ------------------------------------------------------------------------------
# Transit Gateway Resource
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ec2_transit_gateway
# This section creates an AWS Transit Gateway with various configurations such as ASN, DNS support, and route table associations.
# The Transit Gateway allows for interconnecting VPCs and on-premises networks, providing a scalable and flexible network architecture.
# ------------------------------------------------------------------------------

resource "aws_ec2_transit_gateway" "this" {
  description                     = var.description
  amazon_side_asn                 = var.amazon_side_asn
  auto_accept_shared_attachments  = var.auto_accept_shared_attachments
  default_route_table_association = var.default_route_table_association
  default_route_table_propagation = var.default_route_table_propagation
  dns_support                     = var.dns_support
  vpn_ecmp_support                = var.vpn_ecmp_support

  tags = merge(local.common_tags, {
    "Name" = format("%s-tgw-%s-orgtgw", var.naming_convention_properties.project, var.naming_convention_properties.environment)
  })
}
