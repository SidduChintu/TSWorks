# ------------------------------------------------------------------------------
# Transit Gateway Outputs
#
# USAGE EXAMPLES:
# All outputs can be referenced in other modules using: module.vpc.<output_name>
# ------------------------------------------------------------------------------

output "transit_gateway_id" {
  description = "The ID of the Transit Gateway"
  value       = aws_ec2_transit_gateway.this.id
  # Example usage: 
  # - module.vpc.transit_gateway_id
  # - Use when creating TGW attachments or route table associations
}

output "transit_gateway_arn" {
  description = "The ARN of the Transit Gateway"
  value       = aws_ec2_transit_gateway.this.arn
  # Example usage:
  # - module.vpc.transit_gateway_arn
  # - Use for IAM policies requiring TGW ARN reference
}