# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

# ------------------------------------------------------------------------------
# Transit Gateway Configuration Variables
# This section defines the variables required for configuring the AWS Transit Gateway.
# It includes properties such as description, ASN, auto-accept settings, route table associations,
# DNS support, VPN ECMP support, and tags.
# These variables allow customization of the Transit Gateway setup, including its description,
# Amazon side ASN, and various features like DNS support and route table propagation.
# ------------------------------------------------------------------------------
variable "description" {
  type        = string
  description = "Transit Gateway description"
  default     = "Transit Gateway"
}

variable "amazon_side_asn" {
  type        = number
  description = "ASN for the Amazon side of the BGP session"
  default     = 64512
}

variable "auto_accept_shared_attachments" {
  type    = string
  default = "enable"
}

variable "default_route_table_association" {
  type    = string
  default = "enable"
}

variable "default_route_table_propagation" {
  type    = string
  default = "enable"
}

variable "dns_support" {
  type    = string
  default = "enable"
}

variable "vpn_ecmp_support" {
  type    = string
  default = "enable"
}

variable "tags" {
  type    = map(string)
  default = {}
}
