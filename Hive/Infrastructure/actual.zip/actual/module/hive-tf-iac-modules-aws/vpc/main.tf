# ------------------------------------------------------------------------------
# Local variables & Constants
# ------------------------------------------------------------------------------

locals {
  final_resource_name = "${var.naming_convention_properties.project}-${var.naming_convention_properties.environment}"
  common_tags         = var.tags
  az_map              = { for az in var.azs : az => az }
  nat_gateway_map     = var.single_nat_gateway ? { (keys(var.public_subnets)[0]) = "single" } : { for k in keys(var.public_subnets) : k => "multi" }
}

# ------------------------------------------------------------------------------
# VPC
# https://registry.terraform.io/providers/hashicorp/aws/5.86.1/docs/resources/vpc.html
# This resource defines an Amazon Virtual Private Cloud (VPC) with the specified CIDR block.
# ------------------------------------------------------------------------------

resource "aws_vpc" "vpc" {
  cidr_block           = var.cidr_block
  enable_dns_support   = true
  enable_dns_hostnames = true
  tags                 = merge(local.common_tags, { "Name" = format("%s-vpc-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment) })
}

# ------------------------------------------------------------------------------
# Internet Gateway
# https://registry.terraform.io/providers/hashicorp/aws/5.86.1/docs/resources/internet_gateway
# This resource creates an Internet Gateway for the VPC, allowing communication between instances in the VPC and the internet.
# ------------------------------------------------------------------------------

resource "aws_internet_gateway" "internet_gateway" {
  count  = var.enable_public_subnets ? 1 : 0
  vpc_id = aws_vpc.vpc.id
  tags   = merge(local.common_tags, { "Name" = format("%s-igw-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment) })
}

# ------------------------------------------------------------------------------
# Subnets
# https://registry.terraform.io/providers/hashicorp/aws/5.86.1/docs/resources/subnet
# This section defines the public and private subnets within the VPC.
# Public subnets are used for resources that need direct access to the internet, while private subnets are used for resources that do not require direct internet access.
# ------------------------------------------------------------------------------

# Public Subnets
resource "aws_subnet" "public" {
  for_each = var.enable_public_subnets ? var.public_subnets : {}

  vpc_id            = aws_vpc.vpc.id
  cidr_block        = each.value.cidr_block
  availability_zone = each.value.az

  map_public_ip_on_launch = lookup(each.value, "map_public_ip_on_launch", false)

  tags = merge(local.common_tags, {
    "Name"       = format("%s-subnet-%s-public-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment, each.value.az_alias)
    "SubnetTier" = "Public"
  })
}

# Private Subnets
resource "aws_subnet" "private" {
  for_each = var.private_subnets

  vpc_id            = aws_vpc.vpc.id
  cidr_block        = each.value.cidr_block
  availability_zone = each.value.az

  tags = merge(local.common_tags, {
    "Name"       = format("%s-subnet-%s-private-%s-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment, each.value.purpose, each.value.az_alias)
    "SubnetTier" = "Private"
  })
}

# ------------------------------------------------------------------------------
# Elastic IPs for NAT Gateways
# https://registry.terraform.io/providers/hashicorp/aws/5.86.1/docs/resources/eip
# This section allocates Elastic IPs for the NAT Gateways in the public subnets. These EIPs are used to provide internet access to instances in private subnets.
# ------------------------------------------------------------------------------

resource "aws_eip" "elastic_ips" {
  for_each = local.nat_gateway_map

  domain     = "vpc"
  depends_on = [aws_internet_gateway.internet_gateway]
  tags       = { "Name" = format("%s-eip-%s-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment, each.key) }
}

# ------------------------------------------------------------------------------
# NAT Gateways
# https://registry.terraform.io/providers/hashicorp/aws/5.86.1/docs/resources/nat_gateway
# This section creates NAT Gateways for the public subnets, allowing instances in private subnets to access the internet while preventing direct inbound internet traffic.
# ------------------------------------------------------------------------------

resource "aws_nat_gateway" "nat_gateways" {
  for_each = local.nat_gateway_map

  allocation_id = aws_eip.elastic_ips[each.key].id
  subnet_id     = aws_subnet.public[each.key].id

  depends_on = [aws_internet_gateway.internet_gateway]

  tags = {
    Name = format("%s-nat-%s-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment, each.key)
  }
}

# ------------------------------------------------------------------------------
# Route Tables 
# https://registry.terraform.io/providers/hashicorp/aws/5.86.1/docs/resources/route_table
# This section defines the route tables for public and private subnets. Public route tables route traffic to the internet gateway, while private route tables route traffic through NAT gateways.
# ------------------------------------------------------------------------------

# Public Route Tables
# This section creates a public route table for each availability zone (AZ) that has public subnets defined.

resource "aws_route_table" "public_route_tables" {
  for_each = var.enable_public_subnets ? var.public_subnets : {}
  vpc_id   = aws_vpc.vpc.id
  tags     = merge(local.common_tags, { "Name" = format("%s-rt-%s-public-%s-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment, each.value.purpose, each.value.az_alias) })
}

# Private Route Tables
# This section creates a private route table for each AZ that has private subnets defined. These route tables will be used to route traffic through NAT gateways for instances in private subnets.

resource "aws_route_table" "private_route_tables" {
  for_each = var.private_subnets
  vpc_id   = aws_vpc.vpc.id
  tags     = merge(local.common_tags, { "Name" = format("%s-rt-%s-private-%s-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment, each.value.purpose, each.value.az_alias) })
}

# ------------------------------------------------------------------------------
# Routes to the Internet Gateway
# Applicable for each public route table
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route
# This section defines routes in the public route tables that direct traffic to the internet gateway for public subnets.
# ------------------------------------------------------------------------------

resource "aws_route" "routes_to_internet_gateway" {
  for_each               = var.enable_public_subnets ? var.public_subnets : {}
  route_table_id         = aws_route_table.public_route_tables[each.key].id
  gateway_id             = aws_internet_gateway.internet_gateway[0].id
  destination_cidr_block = "0.0.0.0/0"
}

# ------------------------------------------------------------------------------
# Public Route Table Associations
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route_table_association
# This section associates the public route tables with the public subnets, allowing instances in those subnets to use the routes defined in the public route tables.
# ------------------------------------------------------------------------------

# Public Route Table Associations
resource "aws_route_table_association" "public_route_tables_associations" {
  for_each       = var.public_subnets
  route_table_id = aws_route_table.public_route_tables[each.key].id
  subnet_id      = aws_subnet.public[each.key].id
}

# Private Route Table Associations
resource "aws_route_table_association" "private_route_tables_associations" {
  for_each       = var.private_subnets
  route_table_id = aws_route_table.private_route_tables[each.key].id
  subnet_id      = aws_subnet.private[each.key].id
}

# ------------------------------------------------------------------------------
# Network Access Control Lists (NACLs)
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/network_acl
# This section defines Network ACLs for the VPC. NACLs provide an additional layer of security by controlling inbound and outbound traffic at the subnet level.
# NACLs can be used to allow or deny traffic based on rules defined for specific protocols, ports, and CIDR blocks.
# ------------------------------------------------------------------------------

resource "aws_network_acl" "network_acls" {
  for_each = var.enable_nacls ? var.network_acls : {}
  vpc_id   = aws_vpc.vpc.id

  # Dynamically reference public or private subnets
  subnet_ids = [
    for subnet in each.value.subnets :
    (
      contains(keys(aws_subnet.public), subnet) ?
      aws_subnet.public[subnet].id :
      aws_subnet.private[subnet].id
    )
  ]

  tags = tomap({ "Name" = format("%s-nacl-%s-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment, each.value.service_name) })

  dynamic "ingress" {
    for_each = each.value.ingress

    content {
      rule_no    = ingress.value.rule_no
      protocol   = ingress.value.protocol
      action     = ingress.value.action
      cidr_block = ingress.value.cidr_block
      from_port  = ingress.value.from_port
      to_port    = ingress.value.to_port
    }
  }

  dynamic "egress" {
    for_each = each.value.egress

    content {
      rule_no    = egress.value.rule_no
      protocol   = egress.value.protocol
      action     = egress.value.action
      cidr_block = egress.value.cidr_block
      from_port  = egress.value.from_port
      to_port    = egress.value.to_port
    }
  }
}

# ------------------------------------------------------------------------------
# VPC Endpoint for S3 
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/vpc_endpoint
# This section creates a VPC Endpoint for S3, allowing private access to S3 resources without traversing the public internet.
# The VPC Endpoint is associated with the private route tables, enabling instances in private subnets to access S3 directly.
# ------------------------------------------------------------------------------

resource "aws_vpc_endpoint" "vpc_s3" {
  count        = var.enable_s3_vpc_endpoint ? 1 : 0
  vpc_id       = aws_vpc.vpc.id
  service_name = "com.amazonaws.us-east-1.s3"

  tags = merge(local.common_tags, {
    "Name" = format("%s-vpce-s3-%s", var.naming_convention_properties.project, var.naming_convention_properties.environment)
  })
}

# ------------------------------------------------------------------------------
# VPC Endpoint Route Table Association for S3
# Associate S3 VPC Gateway Endpoint with Private Route Tables
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/vpc_endpoint_route_table_association
# This section associates the S3 VPC Endpoint with the private route tables, allowing instances in private subnets to access S3 without going through the internet. 
# The association is created for each private route table defined in the configuration.
# ------------------------------------------------------------------------------

resource "aws_vpc_endpoint_route_table_association" "s3" {
  count           = var.enable_s3_vpc_endpoint ? length(keys(aws_route_table.private_route_tables)) : 0
  route_table_id  = values(aws_route_table.private_route_tables)[count.index].id
  vpc_endpoint_id = aws_vpc_endpoint.vpc_s3[0].id
}

# ------------------------------------------------------------------------------
# Default Security Group
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/default_security_group
# This section creates a default security group for the VPC. The default security group allows all inbound traffic from instances within the same security group and allows all outbound traffic to any destination.
# The security group is tagged with the project and environment names for easy identification.
# ------------------------------------------------------------------------------

resource "aws_default_security_group" "default_sg" {
  vpc_id = aws_vpc.vpc.id

  ingress {
    protocol  = -1
    self      = true
    from_port = 0
    to_port   = 0
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(local.common_tags, {
    "Name" = format("%s-sg-%s-defaultsg", var.naming_convention_properties.project, var.naming_convention_properties.environment)
  })
}
