# ------------------------------------------------------------------------------
# This outputs file defines the outputs for the VPC module.
# 
# USAGE EXAMPLES:
# All outputs can be referenced in other modules using: module.vpc.<output_name>
# ------------------------------------------------------------------------------

output "vpc_id" {
  description = "The ID of the VPC."
  value       = aws_vpc.vpc.id
  # Example usage: module.vpc.vpc_id
}

## Output: Public Subnet IDs
output "public_subnet_ids" {
  description = "List of IDs of public subnets."
  value       = [for subnet in aws_subnet.public : subnet.id]
  # Example usage: module.vpc.public_subnet_ids
}

## Output: Private Subnet IDs
output "private_subnet_ids" {
  description = "List of IDs of private subnets."
  value       = [for subnet in aws_subnet.private : subnet.id]
  # Example usage: module.vpc.private_subnet_ids
}

## Output: Public Subnets by Name
output "public_subnets_map" {
  description = "Map of public subnet names to subnet IDs."
  value       = { for k, subnet in aws_subnet.public : k => subnet.id }
  # Example usage: module.vpc.public_subnets_map["subnet_name"]
}

## Output: Private Subnets by Name
output "private_subnets_map" {
  description = "Map of private subnet names to subnet IDs."
  value       = { for k, subnet in aws_subnet.private : k => subnet.id }
  # Example usage: module.vpc.private_subnets_map["subnet_name"]
}

## Output: Availability Zones
output "availability_zones" {
  description = "List of availability zones used."
  value       = var.azs
  # Example usage: module.vpc.availability_zones
}

## Output: Only TGW attach subnet IDs
output "tgw_attach_subnet_ids" {
  description = "List of private subnet IDs intended for TGW attachment."
  value = [
    for key, subnet in var.private_subnets : aws_subnet.private[key].id
    if subnet.purpose == "tgw-attach"
  ]
  # Example usage: module.vpc.tgw_attach_subnet_ids
}

## Data Subnets
output "data_subnet_ids" {
  description = "List of private subnet IDs intended for Database."
  value = [
    for key, subnet in var.private_subnets : aws_subnet.private[key].id
    if subnet.purpose == "data"
  ]
  # Example usage: module.vpc.data_subnet_ids
}

output "data_subnet_id_az1" {
  description = "Private Data subnet ID in us-east-1a only"
  value = try([
    for key, subnet in var.private_subnets : aws_subnet.private[key].id
    if subnet.purpose == "data" && subnet.az == "us-east-1a"
  ][0], null)
  # Example usage: module.vpc.data_subnet_id_az1
}

output "data_subnet_id_az2" {
  description = "Private Data subnet ID in us-east-1b only"
  value = try([
    for key, subnet in var.private_subnets : aws_subnet.private[key].id
    if subnet.purpose == "data" && subnet.az == "us-east-1b"
  ][0], null)
  # Example usage: module.vpc.data_subnet_id_az2
}

## ETL Subnets
output "etl_subnet_ids" {
  description = "List of private subnet IDs intended for ETL."
  value = [
    for key, subnet in var.private_subnets : aws_subnet.private[key].id
    if subnet.purpose == "etl"
  ]
  # Example usage: module.vpc.etl_subnet_ids
}

output "etl_subnet_id_az1" {
  description = "Private ETL subnet ID in us-east-1a only"
  value = try([
    for key, subnet in var.private_subnets : aws_subnet.private[key].id
    if subnet.purpose == "etl" && subnet.az == "us-east-1a"
  ][0], null)
  # Example usage: module.vpc.etl_subnet_id_az1
}

output "etl_subnet_id_az2" {
  description = "Private ETL subnet ID in us-east-1b only"
  value = try([
    for key, subnet in var.private_subnets : aws_subnet.private[key].id
    if subnet.purpose == "etl" && subnet.az == "us-east-1b"
  ][0], null)
  # Example usage: module.vpc.etl_subnet_id_az2
}

output "cicd_subnet_id_az1" {
  description = "Private ETL subnet ID in us-east-1a only"
  value = try([
    for key, subnet in var.private_subnets : aws_subnet.private[key].id
    if subnet.purpose == "cicd" && subnet.az == "us-east-1a"
  ][0], null)
  # Example usage: module.vpc.cicd_subnet_id_az1
}

output "cicd_subnet_id_az2" {
  description = "Private ETL subnet ID in us-east-1b only"
  value = try([
    for key, subnet in var.private_subnets : aws_subnet.private[key].id
    if subnet.purpose == "cicd" && subnet.az == "us-east-1b"
  ][0], null)
  # Example usage: module.vpc.cicd_subnet_id_az2
}

# Output Security Group ID
output "default_security_group_id" {
  description = "ID of the default security group"
  value       = aws_default_security_group.default_sg.id
  # Example usage: module.vpc.default_security_group_id
}

# Output VPC Endpoint ID
output "vpc_endpoint_id" {
  description = "VPC S3 endpoint ID"
  value       = var.enable_s3_vpc_endpoint && length(aws_vpc_endpoint.vpc_s3) > 0 ? aws_vpc_endpoint.vpc_s3[0].id : null
  # Example usage: module.vpc.vpc_endpoint_id
}

# Output NAT Gateway IDs
output "natgw_ids" {
  description = "List of NAT Gateway IDs (if created)"
  value       = var.enable_public_subnets ? [for ngw in aws_nat_gateway.nat_gateways : ngw.id] : []
  # Example usage: module.vpc.natgw_ids
}

# Output Route Table IDs
output "route_table_name_to_id" {
  value = merge(
    { for rt in aws_route_table.public_route_tables : rt.tags["Name"] => rt.id },
    { for rt in aws_route_table.private_route_tables : rt.tags["Name"] => rt.id }
  )
  # Example usage: module.vpc.route_table_name_to_id["route_table_name"]
}