# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

# ------------------------------------------------------------------------------
# VPC Configuration Variables
# This section defines the variables required for configuring the VPC, including CIDR block, availability zones, subnets, network ACLs, route definitions, and tags.
# These variables allow customization of the VPC setup, including public and private subnets, network ACLs, and route tables.
# ------------------------------------------------------------------------------
variable "cidr_block" {
  description = "The CIDR block for the VPC"
  type        = string
}

variable "azs" {
  description = "A list of availability zones"
  type        = map(string)
}

variable "public_subnets" {
  description = "A map of public subnets"
  type = map(object({
    cidr_block   = string
    az           = string
    az_alias     = string
    name         = string
    tier         = string
    subnet_alias = string
    purpose      = string
  }))
  default = {}
}

variable "private_subnets" {
  description = "A map of private subnets"
  type = map(object({
    cidr_block   = string
    az           = string
    az_alias     = string
    name         = string
    tier         = string
    subnet_alias = string
    purpose      = string
  }))
}

variable "network_acls" {
  description = "A map of network ACLs"
  type = map(object({
    subnets = list(string)
    ingress = list(object({
      rule_no    = number
      protocol   = string
      action     = string
      cidr_block = string
      from_port  = number
      to_port    = number
    }))
    egress = list(object({
      rule_no    = number
      protocol   = string
      action     = string
      cidr_block = string
      from_port  = number
      to_port    = number
    }))
    service_name = string
  }))
}

variable "route_definitions" {
  description = "Custom route rules for route tables"
  type = map(object({
    route_table_type       = string
    destination_cidr_block = string
    target_type            = string
    target_key             = string
  }))
  default = {}
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}

variable "enable_public_subnets" {
  description = "Whether to create public subnets"
  type        = bool
  default     = false
}

variable "enable_nat_gateway" {
  description = "Whether to create NAT gateways"
  type        = bool
  default     = false
}

variable "single_nat_gateway" {
  type    = bool
  default = false
}

variable "enable_nacls" {
  description = "Whether to create Network ACLs"
  type        = bool
  default     = true
}

variable "enable_s3_vpc_endpoint" {
  description = "Enable or disable the S3 VPC endpoint"
  type        = bool
  default     = false
}