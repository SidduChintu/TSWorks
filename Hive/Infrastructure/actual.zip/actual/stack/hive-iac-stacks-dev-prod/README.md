# hive-iac-stacks-dev-prod
Defines environment-specific Terraform stacks for Development and Production deployments used by Hivescience’s application workloads.
