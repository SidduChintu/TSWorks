# ------------------------------------------------------------------------------
# Resource Naming Convention Configuration
# ------------------------------------------------------------------------------

naming_convention_properties = {
  project     = "hive"
  environment = "dev"
}

default_tags = {
  "project"     = "hive"
  "environment" = "dev"
  "deployed_by" = "Terraform"
  "ops_team"    = "devops"
}

# ------------------------------------------------------------------------------
# KMS Keys Module Configuration
# ------------------------------------------------------------------------------

kms_keys = {
  data-encryption = {
    key_name            = "data-encryption"
    key_usage           = "ENCRYPT_DECRYPT"
    description         = "Key for encrypting sensitive data"
    alias               = "data-encryption"
    policy              = "policies/kms/data-encryption-kms-key-policy.json.tmpl"
    enable_key_rotation = true
  }
}

# ------------------------------------------------------------------------------
# IAM Roles and Policies Configuration 
# ------------------------------------------------------------------------------

iam_roles = {
  glueService = {
    description        = "Glue Service IAM role"
    managed_policies   = ["arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole"]
    assume_role_policy = "policies/iam-role-policies/glueService-assume-role.json.tmpl"

    inline_policies = {
      AWSGlueServiceRole = {
        policy = "policies/iam-role-policies/glueService-role-policy.json.tmpl"
      }
    }
  }

  ecsTaskRole = {
    description        = "ECS Task IAM role with full access to S3, RDS, Secrets Manager, and network interfaces"
    assume_role_policy = "policies/ecs-role-policies/ecs-task-assume-role.json.tmpl"
    managed_policies = [
      "arn:aws:iam::aws:policy/AmazonS3FullAccess",
      "arn:aws:iam::aws:policy/AmazonRDSFullAccess",
      "arn:aws:iam::aws:policy/SecretsManagerReadWrite",
      "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
    ]

    inline_policies = {
      NetworkInterfacePolicy = {
        policy = "policies/ecs-role-policies/ecs-network-interface-policy.json.tmpl"
      }
      KMSPolicy = {
        policy = "policies/ecs-role-policies/ecs-kms-policy.json.tmpl"
      }
      S3CustomPolicy = {
        policy = "policies/ecs-role-policies/ecs-s3-custom-policy.json.tmpl"
      }
    }
  }

  ecsExecutionRole = {
    description        = "ECS Execution IAM role with full access to S3, RDS, Secrets Manager, and network interfaces"
    assume_role_policy = "policies/ecs-role-policies/ecs-task-assume-role.json.tmpl"
    managed_policies = [
      "arn:aws:iam::aws:policy/AmazonS3FullAccess",
      "arn:aws:iam::aws:policy/AmazonRDSFullAccess",
      "arn:aws:iam::aws:policy/SecretsManagerReadWrite",
      "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
    ]

    inline_policies = {
      NetworkInterfacePolicy = {
        policy = "policies/ecs-role-policies/ecs-network-interface-policy.json.tmpl"
      }
      KMSPolicy = {
        policy = "policies/ecs-role-policies/ecs-kms-policy.json.tmpl"
      }
      S3CustomPolicy = {
        policy = "policies/ecs-role-policies/ecs-s3-custom-policy.json.tmpl"
      }
    }
  }

  # support_role = {
  #   description        = "AWS Support Role"
  #   managed_policies   = ["arn:aws:iam::aws:policy/AWSSupportAccess"]
  #   assume_role_policy = "policies/support-role-policies/support-role-assume-policy.json.tmpl"

  #   inline_policies = {
  #     AWSSupportRole = {
  #       policy = "policies/support-role-policies/support-role-policy.json.tmpl"
  #     }
  #   }
  # }

}

# ------------------------------------------------------------------------------
# VPC Module Configuration
# ------------------------------------------------------------------------------

# VPC CIDR
cidr_block = "10.3.0.0/16"

# Availability Zones
azs = {
  "us-east-1a" = "az1"
  "us-east-1b" = "az2"
}

# VPC Endpoint for S3
enable_s3_vpc_endpoint = true

# Private Subnets
private_subnets = {
  # Transit Gateway Attach
  Az1TGWAttach01 = {
    cidr_block   = "10.3.0.0/24"
    az           = "us-east-1a"
    az_alias     = "az1"
    name         = "Az1TGWAttach01"
    tier         = "TGWAttachSubnet"
    subnet_alias = "TGWAttach01"
    purpose      = "tgw-attach"
  }
  Az2TGWAttach01 = {
    cidr_block   = "10.3.1.0/24"
    az           = "us-east-1b"
    az_alias     = "az2"
    name         = "Az2TGWAttach01"
    tier         = "TGWAttachSubnet"
    subnet_alias = "TGWAttach02"
    purpose      = "tgw-attach"
  }

  # ETL Subnets
  Az1ETL01 = {
    cidr_block   = "10.3.2.0/24"
    az           = "us-east-1a"
    az_alias     = "az1"
    name         = "Az1ETL01"
    tier         = "ETLSubnet"
    subnet_alias = "ETL01"
    purpose      = "etl"
  }
  Az2ETL01 = {
    cidr_block   = "10.3.3.0/24"
    az           = "us-east-1b"
    az_alias     = "az2"
    name         = "Az2ETL01"
    tier         = "ETLSubnet"
    subnet_alias = "ETL02"
    purpose      = "etl"
  }

  # Data Subnets
  Az1Data01 = {
    cidr_block   = "10.3.4.0/24"
    az           = "us-east-1a"
    az_alias     = "az1"
    name         = "Az1Data01"
    tier         = "DataSubnet"
    subnet_alias = "Data01"
    purpose      = "data"
  }
  Az2Data01 = {
    cidr_block   = "10.3.5.0/24"
    az           = "us-east-1b"
    az_alias     = "az2"
    name         = "Az2Data01"
    tier         = "DataSubnet"
    subnet_alias = "Data02"
    purpose      = "data"
  }

  # ML Subnets
  Az1ML01 = {
    cidr_block   = "10.3.6.0/24"
    az           = "us-east-1a"
    az_alias     = "az1"
    name         = "Az1ML01"
    tier         = "MLSubnet"
    subnet_alias = "ML01"
    purpose      = "ml"
  }
  Az2ML01 = {
    cidr_block   = "10.3.7.0/24"
    az           = "us-east-1b"
    az_alias     = "az2"
    name         = "Az2ML01"
    tier         = "MLSubnet"
    subnet_alias = "ML02"
    purpose      = "ml"
  }

}

# Network ACLs per Subnet Group
network_acls = {

  TGWAttachNACL = {
    subnets = ["Az1TGWAttach01", "Az2TGWAttach01"]
    ingress = [
      {
        rule_no    = 100
        protocol   = "-1"
        action     = "allow"
        cidr_block = "10.1.0.0/16"
        from_port  = 0
        to_port    = 0
      },
      {
        rule_no    = 110
        protocol   = "-1"
        action     = "allow"
        cidr_block = "10.3.0.0/16"
        from_port  = 0
        to_port    = 0
      }
    ]
    egress = [
      {
        rule_no    = 100
        protocol   = "-1"
        action     = "allow"
        cidr_block = "0.0.0.0/0"
        from_port  = 0
        to_port    = 0
      }
    ]
    service_name = "tgw-attach"
  }

  ETLNACL = {
    subnets = ["Az1ETL01", "Az2ETL01"]
    ingress = [
      {
        rule_no    = 100
        protocol   = "-1"
        action     = "allow"
        cidr_block = "10.1.0.0/16"
        from_port  = 0
        to_port    = 0
      },
      {
        rule_no    = 110
        protocol   = "-1"
        action     = "allow"
        cidr_block = "10.3.0.0/16"
        from_port  = 0
        to_port    = 0
      },
      {
        rule_no    = 120
        protocol   = "6"
        action     = "allow"
        cidr_block = "0.0.0.0/0"
        from_port  = 1024
        to_port    = 65535
      }
    ]
    egress = [
      {
        rule_no    = 100
        protocol   = "-1"
        action     = "allow"
        cidr_block = "0.0.0.0/0"
        from_port  = 0
        to_port    = 0
      }
    ]
    service_name = "etl"
  }

  DataNACL = {
    subnets = ["Az1Data01", "Az2Data01"]
    ingress = [
      {
        rule_no    = 100
        protocol   = "-1"
        action     = "allow"
        cidr_block = "10.1.0.0/16"
        from_port  = 0
        to_port    = 0
      },
      {
        rule_no    = 110
        protocol   = "-1"
        action     = "allow"
        cidr_block = "10.3.0.0/16"
        from_port  = 0
        to_port    = 0
      },
      {
        rule_no    = 120
        protocol   = "-1"
        action     = "allow"
        cidr_block = "0.0.0.0/0"
        from_port  = 0
        to_port    = 0
      }
    ]
    egress = [
      {
        rule_no    = 100
        protocol   = "-1"
        action     = "allow"
        cidr_block = "0.0.0.0/0"
        from_port  = 0
        to_port    = 0
      }
    ]
    service_name = "data"
  }

  MLNACL = {
    subnets = ["Az1ML01", "Az2ML01"]
    ingress = [
      {
        rule_no    = 100
        protocol   = "-1"
        action     = "allow"
        cidr_block = "10.1.0.0/16"
        from_port  = 0
        to_port    = 0
      },
      {
        rule_no    = 110
        protocol   = "-1"
        action     = "allow"
        cidr_block = "10.3.0.0/16"
        from_port  = 0
        to_port    = 0
      }
    ]
    egress = [
      {
        rule_no    = 100
        protocol   = "-1"
        action     = "allow"
        cidr_block = "0.0.0.0/0"
        from_port  = 0
        to_port    = 0
      }
    ]
    service_name = "ml"
  }
}

# ------------------------------------------------------------------------------
# Transit Gateway Attachment Module Configuration
# ------------------------------------------------------------------------------

transit_gateway_id = "tgw-0a0fd868f811140b4"

# ------------------------------------------------------------------------------
# Route Module Configuration
# ------------------------------------------------------------------------------

routes_per_table = {
  "hive-rt-dev-private-tgw-attach-az1" = [
    {
      destination_cidr_block = "0.0.0.0/0"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    },
    {
      destination_cidr_block = "10.1.0.0/16"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    }
  ],
  "hive-rt-dev-private-tgw-attach-az2" = [
    {
      destination_cidr_block = "0.0.0.0/0"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    },
    {
      destination_cidr_block = "10.1.0.0/16"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    }
  ],
  "hive-rt-dev-private-etl-az1" = [
    {
      destination_cidr_block = "0.0.0.0/0"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    },
    {
      destination_cidr_block = "10.1.0.0/16"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    }
  ],
  "hive-rt-dev-private-etl-az2" = [
    {
      destination_cidr_block = "0.0.0.0/0"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    },
    {
      destination_cidr_block = "10.1.0.0/16"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    }
  ],
  "hive-rt-dev-private-data-az1" = [
    {
      destination_cidr_block = "0.0.0.0/0"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    },
    {
      destination_cidr_block = "10.1.0.0/16"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    }
  ],
  "hive-rt-dev-private-data-az2" = [
    {
      destination_cidr_block = "0.0.0.0/0"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    },
    {
      destination_cidr_block = "10.1.0.0/16"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    }
  ],
  "hive-rt-dev-private-ml-az1" = [
    {
      destination_cidr_block = "0.0.0.0/0"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    },
    {
      destination_cidr_block = "10.1.0.0/16"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    }
  ],
  "hive-rt-dev-private-ml-az2" = [
    {
      destination_cidr_block = "0.0.0.0/0"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    },
    {
      destination_cidr_block = "10.1.0.0/16"
      transit_gateway_id     = "tgw-0a0fd868f811140b4"
    }
  ]
}

# ------------------------------------------------------------------------------
# RDS Cluster Module Configuration
# ------------------------------------------------------------------------------

db_subnet_group_name = "psqlrdscluster"

rds_cluster_security_group_name = "psqlrdscluster"

rds_cluster_identifier     = "psqlrdscluster"
rds_cluster_engine         = "aurora-postgresql"
rds_cluster_engine_version = "16.6"

rds_cluster_backup_retention_period = 7

rds_cluster_serverlessv2_scaling_configuration = {
  max_capacity = 16
  min_capacity = 1
}

rds_cluster_database_name                                  = "hive"
rds_cluster_instance_enable_enhanced_monitoring            = true
rds_enhanced_monitoring_iam_role_name                      = "rds-enhanced-monitoring-role"
rds_cluster_instance_monitoring_interval                   = 60
rds_cluster_instance_performance_insights_enabled          = true
rds_cluster_instance_performance_insights_retention_period = 7

rds_cluster_availability_zones              = ["us-east-1a", "us-east-1b"]
rds_cluster_enabled_cloudwatch_logs_exports = ["postgresql"]

rds_security_group_ingress_rules = [
  {
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = ["10.1.0.0/16", "10.3.0.0/16"]
    description = "Allow PostgreSQL from internal subnets"
  }
]

rds_security_group_egress_rules = [
  {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
    description = "Allow all outbound traffic"
  }
]


# ------------------------------------------------------------------------------
# Temp RDS Cluster Module Configuration [Need to remove after testing]
# ------------------------------------------------------------------------------

# db_subnet_group_name_temp = "psqlrdsclustertemp"

# rds_cluster_security_group_name_temp = "psqlrdsclustertemp"

# rds_cluster_identifier_temp     = "psqlrdsclustertemp"
# rds_cluster_engine_temp         = "aurora-postgresql"
# rds_cluster_engine_version_temp = "16.6"

# rds_cluster_backup_retention_period_temp = 7

# rds_cluster_serverlessv2_scaling_configuration_temp = {
#   max_capacity = 16
#   min_capacity = 1
# }

# rds_cluster_database_name_temp                                  = "hive"
# rds_cluster_instance_enable_enhanced_monitoring_temp            = true
# rds_enhanced_monitoring_iam_role_name_temp                      = "rds-enhanced-monitoring-role-temp"
# rds_cluster_instance_monitoring_interval_temp                   = 60
# rds_cluster_instance_performance_insights_enabled_temp          = true
# rds_cluster_instance_performance_insights_retention_period_temp = 7

# rds_cluster_availability_zones_temp              = ["us-east-1a", "us-east-1b"]
# rds_cluster_enabled_cloudwatch_logs_exports_temp = ["postgresql"]

# rds_security_group_ingress_rules_temp = [
#   {
#     from_port   = 5432
#     to_port     = 5432
#     protocol    = "tcp"
#     cidr_blocks = ["10.1.0.0/16", "10.2.0.0/16", "10.3.0.0/16"]
#     description = "Allow PostgreSQL from internal subnets"
#   }
# ]

# rds_security_group_egress_rules_temp = [
#   {
#     from_port   = 0
#     to_port     = 0
#     protocol    = "-1"
#     cidr_blocks = ["0.0.0.0/0"]
#     description = "Allow all outbound traffic"
#   }
# ]

# ------------------------------------------------------------------------------
# Lambda Functions Module Configuration
# ------------------------------------------------------------------------------

lambda_functions = {
  glue-pipeline-trigger = {
    description           = "Lambda function which triggers glue jobs"
    handler               = "lambda_function.lambda_handler"
    runtime               = "python3.13"
    filename              = "lambda_function.zip"
    memory_size           = 128
    timeout               = 30
    publish               = true
    log_retention_in_days = 7

    managed_policies   = ["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"]
    inline_policies = {
      merge-service-policy = {
        policy = "policies/lambda/lambda-inline-policy.json.tmpl"
      }
    }
  },
  s3-api = {
    description           = "Lambda function for s3 api."
    handler               = "lambda_function.lambda_handler"
    runtime               = "python3.11"
    filename              = "lambda_function.zip"
    memory_size           = 128
    timeout               = 30
    publish               = true
    log_retention_in_days = 7

    managed_policies   = ["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"]
    inline_policies = {
      s3-api-policy = {
        policy = "policies/lambda/lambda-inline-policy.json.tmpl"
      }
    }
  }
}

# ------------------------------------------------------------------------------
# API Gateway Module Configuration
# ------------------------------------------------------------------------------

api_gateways = {
  s3_api = {
    api_name        = "s3-api"
    api_description = "API Gateway for S3 operations"
    endpoint_type   = "REGIONAL"
    enable_logging  = true
    stage_name      = "dev"

    resources = {
      proxy = {
        parent_id = "root"
        path_part = "{proxy+}"
      }
    }

    methods = {
      proxy_any = {
        resource_key     = "proxy"
        http_method      = "ANY"
        authorization    = "NONE"
        api_key_required = true
      }
    }

    lambda_integrations = {
      proxy_lambda = {
        lambda_function_name    = "hive-lambda-dev-s3-api"
        resource_key            = "proxy"
        http_method             = "ANY"
        integration_http_method = "POST"
        type                    = "AWS_PROXY"
      }
    }

    method_settings = {
      "*/*" = {
        metrics_enabled        = true
        logging_level          = "INFO"
        data_trace_enabled     = false
        throttling_burst_limit = 5000
        throttling_rate_limit  = 2000
      }
    }

    deployment_description = "API Gateway deployment for proxy integration"
  }
}

# ------------------------------------------------------------------------------
# S3 Bucket Module Configuration
# ------------------------------------------------------------------------------

s3_buckets = {
  data_bucket = {
    name          = "data"
    sse_algorithm = "aws:kms"
    kms_key_name  = "data-encryption"
    policy        = "policies/s3-bucket-policies/data-bucket-policy.json.tmpl"
    event_notifications = [
      {
        name                 = "hive-event-dev-s3-glue-pipeline-lambda-trigger"
        event_types          = ["s3:ObjectCreated:*"]
        filter_prefix        = "BaU/"
        filter_suffix        = ".csv"
        destination_type     = "Lambda function"
        lambda_function_name = "hive-lambda-dev-glue-pipeline-trigger"
      }
    ]
  }
}

# ------------------------------------------------------------------------------
# Glue Module Configuration
# ------------------------------------------------------------------------------

security_configurations = {
  sec_config1 = {
    name = "security-configuration"
    encryption_configuration = {
      s3_encryption = {
        s3_encryption_mode = "SSE-S3"
      }
      cloudwatch_encryption = {
        cloudwatch_encryption_mode = "DISABLED"
      }
      job_bookmarks_encryption = {
        job_bookmarks_encryption_mode = "DISABLED"
      }
    }
  }
}

# ------------------------------------------------------------------------------
# ECR Module Configuration
# ------------------------------------------------------------------------------

ecr_repositories = {
  "lambda-deployment" = {
    repository_name      = "lambda-deployment"
    image_tag_mutability = "IMMUTABLE"
    force_delete         = false

    image_scanning_configuration = {
      scan_on_push = true
    }
  }

    "demographics-repo" = {
    repository_name      = "demographics-module1"
    image_tag_mutability = "MUTABLE"
    force_delete         = true
    # Define the lifecycle policy as a Terraform map
    lifecycle_policy = {
      rules = [
        {
          rule_priority = 1
          description   = "Keep only the last 10 images"
          selection = {
            tagStatus   = "any"
            countType   = "imageCountMoreThan"
            countNumber = 10
          }
          action = {
            type = "expire"
          }
        },
        {
          rule_priority = 2
          description   = "Remove untagged images older than 7 days"
          selection = {
            tagStatus   = "untagged"
            countType   = "sinceImagePushed"
            countUnit   = "days"
            countNumber = 7
          }
          action = {
            type = "expire"
          }
        }
      ]
    }
    encryption_configuration = {
      encryption_type = "AES256"
    }

    image_scanning_configuration = {
      scan_on_push = true
    }
  }

  "framework-repo" = {
    repository_name      = "framework-module1"
    image_tag_mutability = "MUTABLE"
    force_delete         = true
    # Define the lifecycle policy as a Terraform map
    lifecycle_policy = {
      rules = [
        {
          rule_priority = 1
          description   = "Keep only the last 10 images"
          selection = {
            tagStatus   = "any"
            countType   = "imageCountMoreThan"
            countNumber = 10
          }
          action = {
            type = "expire"
          }
        },
        {
          rule_priority = 2
          description   = "Remove untagged images older than 7 days"
          selection = {
            tagStatus   = "untagged"
            countType   = "sinceImagePushed"
            countUnit   = "days"
            countNumber = 7
          }
          action = {
            type = "expire"
          }
        }
      ]
    }
    encryption_configuration = {
      encryption_type = "AES256"
    }

    image_scanning_configuration = {
      scan_on_push = true
    }
  }

  "surface-repo" = {
    repository_name      = "surface-module1"
    image_tag_mutability = "MUTABLE"
    force_delete         = true
    # Define the lifecycle policy as a Terraform map
    lifecycle_policy = {
      rules = [
        {
          rule_priority = 1
          description   = "Keep only the last 10 images"
          selection = {
            tagStatus   = "any"
            countType   = "imageCountMoreThan"
            countNumber = 10
          }
          action = {
            type = "expire"
          }
        },
        {
          rule_priority = 2
          description   = "Remove untagged images older than 7 days"
          selection = {
            tagStatus   = "untagged"
            countType   = "sinceImagePushed"
            countUnit   = "days"
            countNumber = 7
          }
          action = {
            type = "expire"
          }
        }
      ]
    }
    encryption_configuration = {
      encryption_type = "AES256"
    }

    image_scanning_configuration = {
      scan_on_push = true
    }
  }
}

# ------------------------------------------------------------------------------
# ECS Clusters Module Configuration
# ------------------------------------------------------------------------------

ecs_clusters = {
  "python-sql-conversion-module1" = {
    container_insights_enabled = true
  }

  # "worker-cluster" = {
  #   container_insights_enabled = true
  # }

  # "batch-cluster" = {
  #   container_insights_enabled = false
  # }
}

# ------------------------------------------------------------------------------
# ECS Task Definitions - Three task definitions with different containers
# ------------------------------------------------------------------------------
ecs_task_definitions = {
  "demographics" = {
    container_name     = "demographics"
    cluster_key        = "python-sql-conversion-module1"
    cluster            = "python-sql-conversion-module1"
    ecr_repository_key = "demographics-repo"
    image_tag          = "latest"
    cpu                = "512"
    memory             = "1024"

    port_mappings = [
      {
        containerPort = 8080
        hostPort      = 8080
        protocol      = "tcp"
      }
    ]

    environment_variables = [
      {
        name  = "ENVIRONMENT"
        value = "developement"
      },
      {
        name  = "secrets_postgres"
        value = "rds!cluster-4ca6389a-15da-49ee-b31d-03de79159bad"
      },
      {
        name  = "secret_name"
        value = "hive-secret-dev"
      }
    
    ]

    secrets = [
      {
        name      = "DB_PASSWORD"
        valueFrom = "arn:aws:secretsmanager:us-east-1:093427367861:secret:rds!cluster-4ca6389a-15da-49ee-b31d-03de79159bad-C6wBtL:password::"
      },
      {
        name     = "DB_USER"
        valueFrom = "arn:aws:secretsmanager:us-east-1:093427367861:secret:rds!cluster-4ca6389a-15da-49ee-b31d-03de79159bad-C6wBtL:username::"
      },
      {
        name     = "DB_URL"
        valueFrom = "arn:aws:secretsmanager:us-east-1:093427367861:secret:hive-secret-dev-MMncTL:db_url::"
      }
    ]

    log_retention_days = 7
  }

  "framework" = {
    container_name     = "framework"
    cluster_key        = "python-sql-conversion-module1"
    cluster            = "python-sql-conversion-module1"
    ecr_repository_key = "framework-repo"
    image_tag          = "latest"
    cpu                = "512"
    memory             = "1024"

    port_mappings = [
      {
        containerPort = 8081
        hostPort      = 8081
        protocol      = "tcp"
      }
    ]

    environment_variables = [
      {
        name  = "ENVIRONMENT"
        value = "developement"
      },
      {
        name  = "secrets_postgres"
        value = "rds!cluster-4ca6389a-15da-49ee-b31d-03de79159bad"
      },
      {
        name  = "secret_name"
        value = "hive-secret-dev"
      }
    
    ]

    secrets = [
      {
        name      = "DB_PASSWORD"
        valueFrom = "arn:aws:secretsmanager:us-east-1:093427367861:secret:rds!cluster-4ca6389a-15da-49ee-b31d-03de79159bad-C6wBtL:password::"
      },
      {
        name     = "DB_USER"
        valueFrom = "arn:aws:secretsmanager:us-east-1:093427367861:secret:rds!cluster-4ca6389a-15da-49ee-b31d-03de79159bad-C6wBtL:username::"
      },
      {
        name     = "DB_URL"
        valueFrom = "arn:aws:secretsmanager:us-east-1:093427367861:secret:hive-secret-dev-MMncTL:db_url::"
      }
    ]

    log_retention_days = 7
  }

  "surface" = {
    container_name     = "surface"
    cluster_key        = "python-sql-conversion-module1"
    cluster            = "python-sql-conversion-module1"
    ecr_repository_key = "surface-repo"
    image_tag          = "latest"
    cpu                = "256"
    memory             = "512"

    port_mappings = [
      {
        containerPort = 8082
        hostPort      = 8082
        protocol      = "tcp"
      }
    ]

    environment_variables = [
      {
        name  = "ENVIRONMENT"
        value = "developement"
      },
      {
        name  = "secrets_postgres"
        value = "rds!cluster-4ca6389a-15da-49ee-b31d-03de79159bad"
      },
      {
        name  = "secret_name"
        value = "hive-secret-dev"
      }
    
    ]

    secrets = [
      {
        name      = "DB_PASSWORD"
        valueFrom = "arn:aws:secretsmanager:us-east-1:093427367861:secret:rds!cluster-4ca6389a-15da-49ee-b31d-03de79159bad-C6wBtL:password::"
      },
      {
        name     = "DB_USER"
        valueFrom = "arn:aws:secretsmanager:us-east-1:093427367861:secret:rds!cluster-4ca6389a-15da-49ee-b31d-03de79159bad-C6wBtL:username::"
      },
      {
        name     = "DB_URL"
        valueFrom = "arn:aws:secretsmanager:us-east-1:093427367861:secret:hive-secret-dev-MMncTL:db_url::"
      }
    ]

    log_retention_days = 7
  }
}