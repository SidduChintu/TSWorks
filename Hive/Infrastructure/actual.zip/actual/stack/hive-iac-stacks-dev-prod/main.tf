# ------------------------------------------------------------------------------
# Terraform Configuration
# ------------------------------------------------------------------------------

terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "5.86.1"
    }
  }
  backend "s3" {}
}

# ------------------------------------------------------------------------------
# Local variables & Constants
# ------------------------------------------------------------------------------

locals {
  aws_auth_profile = "default"
  region           = "us-east-1"
  region_alias     = "UsE1"
  project          = "hive"

  azs = {
    "Az1" = "us-east-1a"
    "Az2" = "us-east-1b"
  }

  s3_bucket_names = {
    data_bucket        = "${var.naming_convention_properties.project}-s3-${var.naming_convention_properties.environment}-data"
    data_backup_bucket = "${var.naming_convention_properties.project}-s3-${var.naming_convention_properties.environment}-data-backup"
  }

  ecs_iam_role_name = {
    task_role      = "${var.naming_convention_properties.project}-iamrole-${var.naming_convention_properties.environment}-ecsTaskRole-role"
    execution_role = "${var.naming_convention_properties.project}-iamrole-${var.naming_convention_properties.environment}-ecsExecutionRole-role"
  }

  # Single set of template vars
  template_vars = {
    account_id                 = data.aws_caller_identity.current.account_id
    region                     = local.region
    environment                = var.naming_convention_properties.environment
    project                    = local.project
    s3_bucket_name_data        = local.s3_bucket_names.data_bucket
    s3_bucket_name_data_backup = local.s3_bucket_names.data_backup_bucket
  }
}

# AWS account information
data "aws_caller_identity" "current" {}

# ------------------------------------------------------------------------------
# Core Infrastructure Modules
# ------------------------------------------------------------------------------

module "vpc" {
  source                       = "../hive-tf-iac-modules-aws/vpc"
  naming_convention_properties = var.naming_convention_properties
  azs                          = local.azs
  cidr_block                   = var.cidr_block
  private_subnets              = var.private_subnets
  network_acls                 = var.network_acls
  tags                         = var.default_tags
  enable_s3_vpc_endpoint       = var.enable_s3_vpc_endpoint
}

module "kms_keys" {
  source                       = "../hive-tf-iac-modules-aws/kms"
  naming_convention_properties = var.naming_convention_properties
  kms_keys = {
    for key_name, key in var.kms_keys : key_name => merge(key, {
      policy = key.policy != null ? templatefile("${path.module}/${key.policy}", local.template_vars) : null
    })
  }
  tags = var.default_tags
}

# ------------------------------------------------------------------------------
# Updated IAM Roles Module
# ------------------------------------------------------------------------------

module "iam_roles" {
  source                       = "../hive-tf-iac-modules-aws/iam-role"
  naming_convention_properties = var.naming_convention_properties
  tags                         = var.default_tags

  iam_roles = {
    for role_name, role in var.iam_roles : role_name => {
      description        = role.description
      managed_policies   = role.managed_policies
      assume_role_policy = templatefile("${path.module}/${role.assume_role_policy}", local.template_vars)

      inline_policies = {
        for policy_name, policy in try(role.inline_policies, {}) : policy_name => {
          policy = templatefile(
            "${path.module}/${policy.policy}",
            merge(local.template_vars, { kms_key_arn = module.kms_keys.kms_keys["data-encryption"].arn })
          )
        }
      }
    }
  }
  depends_on = [module.kms_keys]
}

# ------------------------------------------------------------------------------
# S3 Bucket Module with Specific Name
# ------------------------------------------------------------------------------

module "s3_bucket" {
  source                       = "../hive-tf-iac-modules-aws/s3"
  naming_convention_properties = var.naming_convention_properties
  s3_buckets = {
    data_bucket = {
      name                = "data"
      sse_algorithm       = var.s3_buckets.data_bucket.sse_algorithm
      lifecycle_days      = lookup(var.s3_buckets.data_bucket, "lifecycle_days", null)
      policy              = try(var.s3_buckets.data_bucket.policy != null ? templatefile("${path.module}/${var.s3_buckets.data_bucket.policy}", merge(local.template_vars, { kms_key_arn = module.kms_keys.kms_keys[var.s3_buckets.data_bucket.kms_key_name].arn })) : null, null)
      event_notifications = lookup(var.s3_buckets.data_bucket, "event_notifications", [])
      kms_key_arn         = var.s3_buckets.data_bucket.sse_algorithm == "aws:kms" ? module.kms_keys.kms_keys[var.s3_buckets.data_bucket.kms_key_name].arn : null
    }
  }
  tags       = var.default_tags
  depends_on = [module.kms_keys, module.lambda_functions]
}

# ------------------------------------------------------------------------------
# Dependent Services Modules (Lambda, RDS, Secrets, Glue)
# ------------------------------------------------------------------------------

module "lambda_functions" {
  source                       = "../hive-tf-iac-modules-aws/lambda"
  naming_convention_properties = var.naming_convention_properties
  tags                         = var.default_tags

  lambda_functions = {
    for func_name, func in var.lambda_functions : func_name => {
      description           = func.description
      handler               = func.handler
      runtime               = func.runtime
      memory_size           = func.memory_size
      timeout               = func.timeout
      publish               = func.publish
      filename              = try(func.filename, null)
      environment_variables = try(func.environment_variables, {})
      vpc_config            = try(func.vpc_config, null)
      log_retention_in_days = func.log_retention_in_days
      ignore_code_and_env   = try(func.ignore_code_and_env, true)
      tags                  = try(func.tags, {})

      assume_role_policy = try(func.assume_role_policy != "" ? templatefile("${path.module}/${func.assume_role_policy}", merge(local.template_vars, { kms_key_arn = module.kms_keys.kms_keys["data-encryption"].arn })) : "", "")
      managed_policies   = try(func.managed_policies, ["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"])

      inline_policies = {
        for policy_name, policy in try(func.inline_policies, {}) : policy_name => {
          policy = templatefile("${path.module}/${policy.policy}", merge(local.template_vars, { kms_key_arn = module.kms_keys.kms_keys["data-encryption"].arn }))
        }
      }
    }
  }
  depends_on = [
    module.iam_roles,
    module.kms_keys
  ]
}

resource "aws_secretsmanager_secret" "secret" {
  name                    = "hive-secret-${var.naming_convention_properties.environment}"
  description             = "Secret for hive ${var.naming_convention_properties.environment} environment"
  recovery_window_in_days = 7
  kms_key_id              = module.kms_keys.kms_keys["data-encryption"].arn
  tags                    = var.default_tags
  depends_on              = [module.kms_keys]
}

module "rds_cluster" {
  source                                                     = "../hive-tf-iac-modules-aws/rds"
  vpc_id                                                     = module.vpc.vpc_id
  naming_convention_properties                               = var.naming_convention_properties
  db_subnet_group_name                                       = var.db_subnet_group_name
  db_subnet_group_subnet_ids                                 = module.vpc.data_subnet_ids
  rds_cluster_security_group_name                            = var.rds_cluster_security_group_name
  rds_cluster_identifier                                     = var.rds_cluster_identifier
  rds_cluster_engine                                         = var.rds_cluster_engine
  rds_cluster_engine_version                                 = var.rds_cluster_engine_version
  rds_cluster_database_name                                  = var.rds_cluster_database_name
  rds_cluster_backup_retention_period                        = var.rds_cluster_backup_retention_period
  rds_cluster_serverlessv2_scaling_configuration             = var.rds_cluster_serverlessv2_scaling_configuration
  rds_cluster_instance_enable_enhanced_monitoring            = var.rds_cluster_instance_enable_enhanced_monitoring
  rds_enhanced_monitoring_iam_role_name                      = var.rds_enhanced_monitoring_iam_role_name
  rds_cluster_instance_monitoring_interval                   = var.rds_cluster_instance_monitoring_interval
  rds_cluster_instance_performance_insights_enabled          = var.rds_cluster_instance_performance_insights_enabled
  rds_cluster_instance_performance_insights_retention_period = var.rds_cluster_instance_performance_insights_retention_period
  rds_cluster_availability_zones                             = var.rds_cluster_availability_zones
  rds_cluster_enabled_cloudwatch_logs_exports                = var.rds_cluster_enabled_cloudwatch_logs_exports
  rds_security_group_ingress_rules                           = var.rds_security_group_ingress_rules
  rds_security_group_egress_rules                            = var.rds_security_group_egress_rules
  create_rds_cluster_reader_instance                         = var.create_rds_cluster_reader_instance
  tags                                                       = var.default_tags
  depends_on = [
    module.vpc,
    module.kms_keys
  ]
}

# module "rds_cluster_temp" {
#   source                                                     = "../hive-tf-iac-modules-aws/rds"
#   vpc_id                                                     = module.vpc.vpc_id
#   naming_convention_properties                               = var.naming_convention_properties
#   db_subnet_group_name                                       = var.db_subnet_group_name_temp
#   db_subnet_group_subnet_ids                                 = module.vpc.data_subnet_ids
#   rds_cluster_security_group_name                            = var.rds_cluster_security_group_name_temp
#   rds_cluster_identifier                                     = var.rds_cluster_identifier_temp
#   rds_cluster_engine                                         = var.rds_cluster_engine_temp
#   rds_cluster_engine_version                                 = var.rds_cluster_engine_version_temp
#   rds_cluster_database_name                                  = var.rds_cluster_database_name_temp
#   rds_cluster_backup_retention_period                        = var.rds_cluster_backup_retention_period_temp
#   rds_cluster_serverlessv2_scaling_configuration             = var.rds_cluster_serverlessv2_scaling_configuration_temp
#   rds_cluster_instance_enable_enhanced_monitoring            = var.rds_cluster_instance_enable_enhanced_monitoring_temp
#   rds_enhanced_monitoring_iam_role_name                      = var.rds_enhanced_monitoring_iam_role_name_temp
#   rds_cluster_instance_monitoring_interval                   = var.rds_cluster_instance_monitoring_interval_temp
#   rds_cluster_instance_performance_insights_enabled          = var.rds_cluster_instance_performance_insights_enabled_temp
#   rds_cluster_instance_performance_insights_retention_period = var.rds_cluster_instance_performance_insights_retention_period_temp
#   rds_cluster_availability_zones                             = var.rds_cluster_availability_zones_temp
#   rds_cluster_enabled_cloudwatch_logs_exports                = var.rds_cluster_enabled_cloudwatch_logs_exports_temp
#   rds_security_group_ingress_rules                           = var.rds_security_group_ingress_rules_temp
#   rds_security_group_egress_rules                            = var.rds_security_group_egress_rules_temp
#   create_rds_cluster_reader_instance                         = var.create_rds_cluster_reader_instance_temp
#   tags                                                       = var.default_tags
#   depends_on = [
#     module.vpc,
#     module.kms_keys
#   ]
# }

module "glue" {
  source                       = "../hive-tf-iac-modules-aws/glue"
  naming_convention_properties = var.naming_convention_properties
  connections = {
    s3_connection = {
      name            = "s3-network-connection"
      connection_type = "NETWORK"
      description     = "S3 connection for Glue"
      connection_properties = {
        "ENDPOINT" = "s3.amazonaws.com"
      }
      physical_connection_requirements = {
        availability_zone      = local.azs.Az1
        subnet_id              = module.vpc.etl_subnet_id_az1
        security_group_id_list = [module.vpc.default_security_group_id]
      }
    }
  }
  security_configurations = var.security_configurations
  tags                    = var.default_tags
  depends_on              = [module.vpc]
}

# ------------------------------------------------------------------------------
# Higher-Level Services Modules (API Gateway, TGW Attachment)
# ------------------------------------------------------------------------------

module "api_gateways" {
  for_each                     = var.api_gateways
  source                       = "../hive-tf-iac-modules-aws/api-gateway"
  naming_convention_properties = var.naming_convention_properties
  api_name                     = each.value.api_name
  api_description              = try(each.value.api_description, null)
  endpoint_type                = try(each.value.endpoint_type, "REGIONAL")
  enable_logging               = try(each.value.enable_logging, false)
  stage_name                   = each.value.stage_name
  resources                    = try(each.value.resources, {})
  methods                      = try(each.value.methods, {})
  integrations                 = try(each.value.integrations, {})
  lambda_integrations          = try(each.value.lambda_integrations, {})
  method_settings              = try(each.value.method_settings, {})
  deployment_description       = try(each.value.deployment_description, "")
  stage_variables              = try(each.value.stage_variables, {})
  api_keys                     = try(each.value.api_keys, {})
  openapi_spec                 = try(each.value.openapi_spec, null)
  access_log_settings          = try(each.value.access_log_settings, null)
  create_usage_plan            = try(each.value.create_usage_plan, false)
  usage_plan_name              = try(each.value.usage_plan_name, null)
  usage_plan_description       = try(each.value.usage_plan_description, null)
  usage_plan_api_stages        = try(each.value.usage_plan_api_stages, [])
  usage_plan_quota_settings    = try(each.value.usage_plan_quota_settings, null)
  usage_plan_throttle_settings = try(each.value.usage_plan_throttle_settings, null)
  usage_plan_keys              = try(each.value.usage_plan_keys, {})
  tags                         = var.default_tags
  depends_on                   = [module.lambda_functions]
}

module "tgw_attachment" {
  source                       = "../hive-tf-iac-modules-aws/tgw-attachment"
  naming_convention_properties = var.naming_convention_properties
  vpc_id                       = module.vpc.vpc_id
  subnet_ids                   = module.vpc.tgw_attach_subnet_ids
  transit_gateway_id           = var.transit_gateway_id
  tags                         = var.default_tags
  depends_on                   = [module.vpc]
}

# ------------------------------------------------------------------------------
# Route Module Call (depends on VPC) 
# ------------------------------------------------------------------------------

module "routes" {
  source                 = "../hive-tf-iac-modules-aws/route"
  route_table_name_to_id = module.vpc.route_table_name_to_id
  routes_per_table       = var.routes_per_table
  depends_on             = [module.vpc, module.tgw_attachment]
}

# ------------------------------------------------------------------------------
# ECR Repositories Module Call
# ------------------------------------------------------------------------------

module "ecr_repositories" {
  source                       = "../hive-tf-iac-modules-aws/ecr"
  naming_convention_properties = var.naming_convention_properties
  for_each                     = var.ecr_repositories

  repository_name      = each.value.repository_name
  image_tag_mutability = each.value.image_tag_mutability
  force_delete         = each.value.force_delete

  encryption_configuration     = each.value.encryption_configuration
  image_scanning_configuration = each.value.image_scanning_configuration

  tags = merge(
    var.default_tags,
    { Name = each.value.repository_name }
  )
}

# Create ECS Cluster (single cluster for all tasks)
module "ecs_cluster" {
  source                       = "../hive-tf-iac-modules-aws/ecs"
  naming_convention_properties = var.naming_convention_properties

  task_name              = "python-sql-conversion-module1" # Placeholder name
  container_name         = "placeholder"
  container_image        = "placeholder:latest"
  task_role_arn          = module.iam_roles.iam_roles[local.ecs_iam_role_name.task_role].arn
  execution_role_arn     = module.iam_roles.iam_roles[local.ecs_iam_role_name.execution_role].arn
  aws_region             = local.region
  for_each               = var.ecs_clusters

  cluster_name               = each.key
  create_task_definition  = false
  cluster_name_suffix     = "-${each.key}"
  container_insights_enabled = each.value.container_insights_enabled
  
  tags = merge(
    var.default_tags,
    { Name = each.key }
  )
}

# Create ECS Task Definitions
module "ecs_task_definitions" {
  source                       = "../hive-tf-iac-modules-aws/ecs"
  naming_convention_properties = var.naming_convention_properties
  for_each                     = var.ecs_task_definitions
  create_cluster          = false
  create_task_definition  = true
  cluster_name          = module.ecs_cluster[each.value.cluster_key].cluster_name
  task_name              = each.key
  container_name         = each.value.container_name
  container_image        = "${module.ecr_repositories[each.value.ecr_repository_key].repository_url}:latest"
  cpu                    = each.value.cpu
  memory                 = each.value.memory
  task_role_arn          = module.iam_roles.iam_roles[local.ecs_iam_role_name.task_role].arn
  execution_role_arn     = module.iam_roles.iam_roles[local.ecs_iam_role_name.execution_role].arn
  aws_region             = local.region
  port_mappings          = each.value.port_mappings
  environment_variables  = each.value.environment_variables
  secrets                = each.value.secrets
  mount_points           = each.value.mount_points
  volumes_from           = each.value.volumes_from
  volumes                = each.value.volumes
  log_retention_days     = each.value.log_retention_days
  container_insights_enabled = var.container_insights_enabled

  tags = merge(
    var.default_tags,
    { Name = each.key }
  )

  depends_on = [
    module.ecr_repositories,
    module.iam_roles,
    module.ecs_cluster
  ]
}