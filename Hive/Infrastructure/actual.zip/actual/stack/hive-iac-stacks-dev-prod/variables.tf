# ------------------------------------------------------------------------------
# Resource Naming Convention
# This module defines the naming convention properties for AWS resources.
# It includes project, environment, purpose, and optional index.
# ------------------------------------------------------------------------------

variable "naming_convention_properties" {
  description = "Naming convention properties for AWS resources"
  type = object({
    project     = string
    environment = string
    purpose     = optional(string)
    index       = optional(string)
  })
}

variable "default_tags" {
  description = "Default tags to apply to all resources"
  type        = map(string)
  default     = {}
}

# ------------------------------------------------------------------------------
# KMS Keys Module
# This module creates KMS keys with various configurations.
# It supports symmetric and asymmetric keys, key policies, and additional configurations.
# It also allows for advanced options like multi-region keys and key rotation.
# ------------------------------------------------------------------------------

variable "kms_keys" {
  description = "Map of KMS keys to create"
  type = map(object({
    key_name    = string
    description = string
    alias       = optional(string)
    policy      = optional(string)

    # Key configuration
    deletion_window_in_days = optional(number, 30)
    enable_key_rotation     = optional(bool, true)
    is_enabled              = optional(bool, true)
    multi_region            = optional(bool, false)

    # Key specifications
    key_usage                = optional(string, "ENCRYPT_DECRYPT")
    customer_master_key_spec = optional(string, "SYMMETRIC_DEFAULT")

    # Advanced options
    bypass_policy_lockout_safety_check = optional(bool, false)

    # Additional policy statements
    additional_policy_statements = optional(list(object({
      sid       = string
      effect    = string
      actions   = list(string)
      resources = list(string)
      principal = object({
        type        = string
        identifiers = list(string)
      })
      condition = optional(object({
        test     = string
        variable = string
        values   = list(string)
      }))
    })), [])

    # Tags
    tags = optional(map(string), {})
  }))
}

# ------------------------------------------------------------------------------
# IAM Roles Module
# This module creates IAM roles with various configurations.
# It includes support for managed policies, inline policies, and assume role policies.
# ------------------------------------------------------------------------------

variable "iam_roles" {
  description = "Map of IAM roles with their policies"
  type = map(object({
    description          = optional(string)
    path                 = optional(string, "/")
    max_session_duration = optional(number, 3600)
    assume_role_policy   = string
    managed_policies     = optional(list(string), [])
    inline_policies = optional(map(object({
      policy = string
    })), {})
  }))
}

# ------------------------------------------------------------------------------
# VPC Module
# This module creates a VPC with private subnets, network ACLs, and optional S3 VPC endpoint.
# It also supports tagging and CIDR block configuration.
# The VPC can be customized with private subnets, availability zones, and network ACLs.
# ------------------------------------------------------------------------------

variable "cidr_block" {
  description = "The CIDR block for the VPC"
  type        = string
}

variable "private_subnets" {
  description = "A map of private subnets"
  type = map(object({
    cidr_block   = string
    az           = string
    az_alias     = string
    name         = string
    tier         = string
    subnet_alias = string
    purpose      = string
  }))
}

variable "azs" {
  description = "A list of availability zones"
  type        = map(string)
}

variable "network_acls" {
  description = "A map of network ACLs"
  type = map(object({
    subnets = list(string)
    ingress = list(object({
      rule_no    = number
      protocol   = string
      action     = string
      cidr_block = string
      from_port  = number
      to_port    = number
    }))
    egress = list(object({
      rule_no    = number
      protocol   = string
      action     = string
      cidr_block = string
      from_port  = number
      to_port    = number
    }))
    service_name = string
  }))
}

variable "enable_s3_vpc_endpoint" {
  description = "Enable or disable the S3 VPC endpoint"
  type        = bool
  default     = false
}

# ------------------------------------------------------------------------------
# Transit Gateway Attachment Module
# This module creates a Transit Gateway Attachment for a VPC.
# ------------------------------------------------------------------------------

variable "transit_gateway_id" {
  description = "ID of the AWS Transit Gateway"
  type        = string
}

# ------------------------------------------------------------------------------
# Route Module
# This module manages routes in the VPC.
# ------------------------------------------------------------------------------

variable "routes_per_table" {
  description = "Map of route table ID to list of route objects"
  type = map(list(object({
    # Destination
    destination_cidr_block      = optional(string)
    destination_ipv6_cidr_block = optional(string)
    destination_prefix_list_id  = optional(string)

    # Target
    carrier_gateway_id        = optional(string)
    core_network_arn          = optional(string)
    egress_only_gateway_id    = optional(string)
    gateway_id                = optional(string)
    nat_gateway_id            = optional(string)
    local_gateway_id          = optional(string)
    network_interface_id      = optional(string)
    transit_gateway_id        = optional(string)
    vpc_endpoint_id           = optional(string)
    vpc_peering_connection_id = optional(string)
  })))
}

# ------------------------------------------------------------------------------
# RDS Cluster Module
# This module creates an RDS Aurora cluster with various configurations.
# ------------------------------------------------------------------------------

variable "rds_cluster_engine" {
  description = "RDS engine (aurora-mysql or aurora-postgresql)"
  type        = string
  default     = "aurora-postgresql"
}

variable "db_subnet_group_name" {
  type        = string
  description = "Name of the DB subnet group"
}

variable "rds_cluster_security_group_name" {
  type        = string
  description = "Name of the RDS security group"
}

variable "rds_cluster_identifier" {
  type        = string
  description = "Identifier for the RDS cluster"
}

variable "rds_cluster_engine_version" {
  type        = string
  description = "Aurora DB engine version"
}

variable "rds_cluster_backup_retention_period" {
  type        = number
  description = "Backup retention in days"
}

variable "rds_cluster_serverlessv2_scaling_configuration" {
  type = object({
    min_capacity = number
    max_capacity = number
  })
  description = "Serverless v2 scaling config"
}

variable "rds_cluster_instance_enable_enhanced_monitoring" {
  type        = bool
  description = "Enable enhanced monitoring"
}

variable "rds_cluster_database_name" {
  description = "The name of the default database in the RDS cluster"
  type        = string
}

variable "rds_enhanced_monitoring_iam_role_name" {
  type        = string
  description = "IAM role for enhanced monitoring"
}

variable "rds_cluster_instance_monitoring_interval" {
  type        = number
  description = "Monitoring interval"
}

variable "rds_cluster_instance_performance_insights_enabled" {
  type        = bool
  description = "Enable Performance Insights"
}

variable "rds_cluster_instance_performance_insights_retention_period" {
  type        = number
  description = "Retention period for Performance Insights"
}

variable "rds_cluster_availability_zones" {
  type        = list(string)
  description = "List of AZs"
}

variable "rds_cluster_enabled_cloudwatch_logs_exports" {
  type        = list(string)
  description = "Enabled logs for CloudWatch"
}

variable "create_rds_cluster_reader_instance" {
  type        = bool
  description = "Whether to create a reader instance"
  default     = false
}

variable "rds_security_group_ingress_rules" {
  description = "List of ingress rules for RDS SG"
  type = list(object({
    from_port   = number
    to_port     = number
    protocol    = string
    cidr_blocks = list(string)
    description = optional(string)
  }))
}

variable "rds_security_group_egress_rules" {
  description = "List of egress rules for RDS SG"
  type = list(object({
    from_port   = number
    to_port     = number
    protocol    = string
    cidr_blocks = list(string)
    description = optional(string)
  }))
}


# ------------------------------------------------------------------------------
# Temp RDS for testing
# RDS Cluster Module
# This module creates an RDS Aurora cluster with various configurations.
# ------------------------------------------------------------------------------

# variable "rds_cluster_engine_temp" {
#   description = "RDS engine (aurora-mysql or aurora-postgresql)"
#   type        = string
#   default     = "aurora-postgresql"
# }

# variable "db_subnet_group_name_temp" {
#   type        = string
#   description = "Name of the DB subnet group"
# }

# variable "rds_cluster_security_group_name_temp" {
#   type        = string
#   description = "Name of the RDS security group"
# }

# variable "rds_cluster_identifier_temp" {
#   type        = string
#   description = "Identifier for the RDS cluster"
# }

# variable "rds_cluster_engine_version_temp" {
#   type        = string
#   description = "Aurora DB engine version"
# }

# variable "rds_cluster_backup_retention_period_temp" {
#   type        = number
#   description = "Backup retention in days"
# }

# variable "rds_cluster_serverlessv2_scaling_configuration_temp" {
#   type = object({
#     min_capacity = number
#     max_capacity = number
#   })
#   description = "Serverless v2 scaling config"
# }

# variable "rds_cluster_instance_enable_enhanced_monitoring_temp" {
#   type        = bool
#   description = "Enable enhanced monitoring"
# }

# variable "rds_cluster_database_name_temp" {
#   description = "The name of the default database in the RDS cluster"
#   type        = string
# }

# variable "rds_enhanced_monitoring_iam_role_name_temp" {
#   type        = string
#   description = "IAM role for enhanced monitoring"
# }

# variable "rds_cluster_instance_monitoring_interval_temp" {
#   type        = number
#   description = "Monitoring interval"
# }

# variable "rds_cluster_instance_performance_insights_enabled_temp" {
#   type        = bool
#   description = "Enable Performance Insights"
# }

# variable "rds_cluster_instance_performance_insights_retention_period_temp" {
#   type        = number
#   description = "Retention period for Performance Insights"
# }

# variable "rds_cluster_availability_zones_temp" {
#   type        = list(string)
#   description = "List of AZs"
# }

# variable "rds_cluster_enabled_cloudwatch_logs_exports_temp" {
#   type        = list(string)
#   description = "Enabled logs for CloudWatch"
# }

# variable "create_rds_cluster_reader_instance_temp" {
#   type        = bool
#   description = "Whether to create a reader instance"
#   default     = false
# }

# variable "rds_security_group_ingress_rules_temp" {
#   description = "List of ingress rules for RDS SG"
#   type = list(object({
#     from_port   = number
#     to_port     = number
#     protocol    = string
#     cidr_blocks = list(string)
#     description = optional(string)
#   }))
# }

# variable "rds_security_group_egress_rules_temp" {
#   description = "List of egress rules for RDS SG"
#   type = list(object({
#     from_port   = number
#     to_port     = number
#     protocol    = string
#     cidr_blocks = list(string)
#     description = optional(string)
#   }))
# }

# ------------------------------------------------------------------------------
# Lambda Functions Module
# This module defines the configuration for AWS Lambda functions.
# ------------------------------------------------------------------------------

variable "lambda_functions" {
  description = "Map of Lambda functions with their config, including role policies"
  type = map(object({
    description           = string
    handler               = string
    runtime               = string
    memory_size           = number
    timeout               = number
    publish               = bool
    filename              = optional(string)
    environment_variables = optional(map(string), {})
    vpc_config = optional(object({
      subnet_ids         = list(string)
      security_group_ids = list(string)
    }), null)
    tags                  = optional(map(string), {})
    log_retention_in_days = number

    # New for IAM Role customization:
    assume_role_policy = optional(string, "")
    managed_policies   = optional(list(string), ["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"])
    inline_policies    = optional(map(object({ policy = string })), {}) # map of name -> { policy = file path }

    # Optional flag to ignore code/env from Terraform
    ignore_code_and_env = optional(bool, true)
  }))
}

# ------------------------------------------------------------------------------
# API Gateway Module
# This module defines the configuration for AWS API Gateway, including REST APIs, resources, methods, integrations, and more.
# ------------------------------------------------------------------------------

variable "api_gateways" {
  description = "Map of API Gateway configurations"
  type = map(object({
    # Basic API Configuration
    api_name        = string
    api_description = optional(string)
    endpoint_type   = optional(string, "REGIONAL")
    enable_logging  = optional(bool, false)
    openapi_spec    = optional(string)
    stage_name      = string

    # Resource Configuration
    resources = optional(map(object({
      parent_id = string
      path_part = string
    })), {})

    # Method Configuration
    methods = optional(map(object({
      resource_key       = string
      http_method        = string
      authorization      = string
      authorizer_id      = optional(string)
      api_key_required   = optional(bool, false)
      request_models     = optional(map(string))
      request_parameters = optional(map(bool))
    })), {})

    # Integration Configuration
    integrations = optional(map(object({
      resource_key            = string
      http_method             = string
      integration_http_method = optional(string)
      type                    = string
      uri                     = optional(string)
      connection_type         = optional(string)
      connection_id           = optional(string)
      credentials             = optional(string)
      request_parameters      = optional(map(string))
      request_templates       = optional(map(string))
      passthrough_behavior    = optional(string, "WHEN_NO_MATCH")
      timeout_milliseconds    = optional(number, 29000)
      content_handling        = optional(string)
    })), {})

    # Lambda Integration Configuration
    lambda_integrations = optional(map(object({
      lambda_function_name    = string
      resource_key            = string
      http_method             = string
      integration_http_method = optional(string, "POST")
      type                    = optional(string, "AWS_PROXY")
      connection_type         = optional(string)
      connection_id           = optional(string)
      credentials             = optional(string)
      request_parameters      = optional(map(string))
      request_templates       = optional(map(string))
    })), {})

    # Deployment Configuration
    deployment_description = optional(string, "Deployed by Terraform")

    # Stage Configuration
    stage_variables = optional(map(string), {})
    access_log_settings = optional(object({
      destination_arn = string
      format          = string
    }))

    # Method Settings
    method_settings = optional(map(object({
      metrics_enabled        = optional(bool, true)
      logging_level          = optional(string, "INFO")
      data_trace_enabled     = optional(bool, false)
      throttling_burst_limit = optional(number)
      throttling_rate_limit  = optional(number)
      caching_enabled        = optional(bool)
      cache_ttl_in_seconds   = optional(number)
      cache_data_encrypted   = optional(bool)
    })), {})

    # API Keys
    api_keys = optional(map(object({
      name        = optional(string)
      description = optional(string)
      value       = optional(string)
      enabled     = optional(bool, true)
    })), {})

    # Usage Plan Configuration
    create_usage_plan      = optional(bool, false)
    usage_plan_name        = optional(string)
    usage_plan_description = optional(string)
    usage_plan_api_stages = optional(list(object({
      api_id = string
      stage  = string
      throttle = optional(map(object({
        burst_limit = number
        rate_limit  = number
      })))
    })), [])

    usage_plan_quota_settings = optional(object({
      limit  = number
      offset = optional(number, 0)
      period = string
    }))

    usage_plan_throttle_settings = optional(object({
      burst_limit = number
      rate_limit  = number
    }))

    usage_plan_keys = optional(map(object({
      key_id        = string
      key_type      = string
      usage_plan_id = string
    })), {})

    # Domain Name Configuration
    domain_name_configuration = optional(object({
      domain_name            = string
      certificate_arn        = string
      security_policy        = optional(string, "TLS_1_2")
      endpoint_configuration = optional(string, "REGIONAL")
      ownership_verification = optional(bool, false)
      mutual_tls_authentication = optional(object({
        truststore_uri     = optional(string)
        truststore_version = optional(string)
      }))
    }))

    # VPC Link Configuration
    vpc_links = optional(map(object({
      name        = string
      description = optional(string)
      target_arns = list(string)
    })), {})

    # Authorizers
    authorizers = optional(map(object({
      name                             = string
      type                             = string
      identity_source                  = optional(string)
      provider_arns                    = optional(list(string))
      authorizer_uri                   = optional(string)
      authorizer_credentials           = optional(string)
      identity_validation_expression   = optional(string)
      authorizer_result_ttl_in_seconds = optional(number, 300)
    })), {})

    # Gateway Responses
    gateway_responses = optional(map(object({
      response_type       = string
      status_code         = optional(string)
      response_parameters = optional(map(string))
      response_templates  = optional(map(string))
    })), {})

    # Request Validators
    request_validators = optional(map(object({
      name                        = string
      validate_request_body       = optional(bool, false)
      validate_request_parameters = optional(bool, false)
    })), {})

    # Models
    models = optional(map(object({
      name         = string
      description  = optional(string)
      content_type = string
      schema       = string
    })), {})
  }))
  default = {}
}

# ------------------------------------------------------------------------------
# S3 Bucket Module
# This module defines the configuration for AWS S3 Bucket, including encryption, bucket policy, event notifications, etc.
# ------------------------------------------------------------------------------

variable "s3_buckets" {
  description = "Map of S3 bucket configurations"
  type = map(object({
    name           = string
    sse_algorithm  = optional(string, "AES256")
    kms_key_name   = optional(string)
    lifecycle_days = optional(number, 30)
    policy         = optional(string)
    event_notifications = optional(list(object({
      name                 = string
      event_types          = list(string)
      filter_prefix        = optional(string)
      filter_suffix        = optional(string)
      destination_type     = string
      lambda_function_name = string
    })), [])
  }))
}

# ------------------------------------------------------------------------------
# Glue Module
# This module defines the configuration for AWS Glue, including Glue DB, Glue Connections, Glue Security Configuration, etc.
# ------------------------------------------------------------------------------

variable "security_configurations" {
  description = "Map of Glue Security Configurations"
  type = map(object({
    deploy = optional(bool, true)
    name   = string
    encryption_configuration = object({
      cloudwatch_encryption = object({
        cloudwatch_encryption_mode = string
        kms_key_arn                = optional(string)
      })
      job_bookmarks_encryption = object({
        job_bookmarks_encryption_mode = string
        kms_key_arn                   = optional(string)
      })
      s3_encryption = object({
        s3_encryption_mode = string
        kms_key_arn        = optional(string)
      })
    })
  }))
  default = {}
}

variable "glue_catalog_database" {
  description = "Map of Glue Catalog Databases"
  type = map(object({
    deploy       = optional(bool, false)
    name         = string
    catalog_id   = optional(string)
    description  = optional(string)
    location_uri = optional(string)
    parameters   = optional(map(string))
    tags         = optional(map(string))

    create_table_default_permission = optional(list(object({
      permissions = list(string)
      principal = object({
        data_lake_principal_identifier = string
      })
    })))

    federated_database = optional(object({
      connection_name = string
      identifier      = string
    }))

    target_database = optional(object({
      catalog_id    = string
      database_name = string
      region        = string
    }))
  }))
  default = {}
}

variable "common_tags" {
  description = "Common tags for all ECR repositories"
  type        = map(string)
  default     = {}
}
# ------------------------------------------------------------------------------
# ECR Module
# This module defines the configuration for AWS ECR repositories.
# ------------------------------------------------------------------------------

variable "ecr_repositories" {
  description = "Map of ECR repository configurations"
  type = map(object({
    repository_name      = string
    image_tag_mutability = optional(string, "MUTABLE")
    force_delete         = optional(bool, false)

    encryption_configuration = optional(object({
      encryption_type = optional(string, "AES256")
      kms_key         = optional(string, null)
    }), null)

    image_scanning_configuration = optional(object({
      scan_on_push = bool
    }), null)

    tags = optional(map(string), {})
  }))

  default = {}
}


# ------------------------------------------------------------------------------
# ECS Module
# This module defines the configuration for AWS ECS clusters and Task Definitions.
# ------------------------------------------------------------------------------ 

variable "container_insights_enabled" {
  description = "Enable container insights for ECS cluster"
  type        = bool
  default     = true
}

variable "ecs_clusters" {
  description = "Map of ECS clusters to create"
  type = map(object({
    container_insights_enabled = optional(bool, true)
  }))
  default = {}
}

variable "ecs_task_definitions" {
  description = "Map of ECS task definitions to create"
  type = map(object({
    cluster_key          = string
    container_name       = string
    ecr_repository_key   = string
    cpu                  = string
    memory               = string
    port_mappings = optional(list(object({
      containerPort = number
      hostPort      = number
      protocol      = string
    })), [])
    environment_variables = optional(list(object({
      name  = string
      value = string
    })), [])
    secrets = optional(list(object({
      name      = string
      valueFrom = string
    })), [])
    mount_points = optional(list(object({
      sourceVolume  = string
      containerPath = string
      readOnly      = bool
    })), [])
    volumes_from = optional(list(any), [])
    volumes = optional(list(object({
      name = string
      efs_volume_configuration = optional(object({
        file_system_id          = string
        root_directory          = optional(string)
        transit_encryption      = optional(string)
        transit_encryption_port = optional(number)
        authorization_config = optional(object({
          access_point_id = optional(string)
          iam             = optional(string)
        }))
      }))
    })), [])
    log_retention_days = optional(number, 7)
  }))
  default = {}
}